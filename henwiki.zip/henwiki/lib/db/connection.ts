import mysql from "mysql2/promise"

// 数据库配置
const dbConfig = {
  host: process.env.DB_HOST || "127.0.0.1",
  port: parseInt(process.env.DB_PORT || "3306"),
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "root",
  database: process.env.DB_NAME || "henwiki",
  waitForConnections: true,
  connectionLimit: 10, // 连接池大小
  queueLimit: 0,
  enableKeepAlive: true,
  keepAliveInitialDelay: 0,
}

// 创建连接池
let pool: mysql.Pool | null = null

export function getPool(): mysql.Pool {
  if (!pool) {
    pool = mysql.createPool(dbConfig)
  }
  return pool
}

// 执行查询的辅助函数
export async function query<T = any>(
  sql: string,
  params?: any[]
): Promise<T[]> {
  try {
    const connection = getPool()
    const [rows] = await connection.execute(sql, params)
    return rows as T[]
  } catch (error: any) {
    if (error.code === "ER_BAD_DB_ERROR") {
      throw new Error(
        `数据库 '${dbConfig.database}' 不存在。请先运行 'pnpm run init-db' 创建数据库。`
      )
    }
    throw error
  }
}

// 执行单个查询（返回第一条结果）
export async function queryOne<T = any>(
  sql: string,
  params?: any[]
): Promise<T | null> {
  const results = await query<T>(sql, params)
  return results.length > 0 ? results[0] : null
}

// 执行插入/更新/删除操作
export async function execute(sql: string, params?: any[]): Promise<mysql.ResultSetHeader> {
  try {
    const connection = getPool()
    const [result] = await connection.execute(sql, params)
    return result as mysql.ResultSetHeader
  } catch (error: any) {
    if (error.code === "ER_BAD_DB_ERROR") {
      throw new Error(
        `数据库 '${dbConfig.database}' 不存在。请先运行 'pnpm run init-db' 创建数据库。`
      )
    }
    throw error
  }
}

// 事务处理
export async function transaction<T>(
  callback: (connection: mysql.PoolConnection) => Promise<T>
): Promise<T> {
  const connection = getPool()
  const conn = await connection.getConnection()
  await conn.beginTransaction()

  try {
    const result = await callback(conn)
    await conn.commit()
    return result
  } catch (error) {
    await conn.rollback()
    throw error
  } finally {
    conn.release()
  }
}

// 关闭连接池（用于测试或应用关闭时）
export async function closePool(): Promise<void> {
  if (pool) {
    await pool.end()
    pool = null
  }
}

// 检查并创建 bookmarks 表（如果不存在）
export async function ensureDiscussionsTable(): Promise<void> {
  try {
    // 检查 discussions 表是否存在
    const result = await query<{ count: number }>(
      `SELECT COUNT(*) as count 
       FROM information_schema.tables 
       WHERE table_schema = ? AND table_name = 'discussions'`,
      [dbConfig.database]
    )

    if (result.length === 0 || result[0].count === 0) {
      // 表不存在，创建它们
      console.log("检测到讨论表不存在，正在创建...")
      
      await execute(`
        CREATE TABLE IF NOT EXISTS discussions (
          id BIGINT PRIMARY KEY AUTO_INCREMENT,
          title VARCHAR(255) NOT NULL,
          content TEXT NOT NULL,
          author_id BIGINT NOT NULL,
          category_id INT,
          views INT DEFAULT 0,
          likes_count INT DEFAULT 0,
          replies_count INT DEFAULT 0,
          is_pinned BOOLEAN DEFAULT FALSE,
          is_locked BOOLEAN DEFAULT FALSE,
          is_featured BOOLEAN DEFAULT FALSE,
          status ENUM('draft', 'published', 'deleted') DEFAULT 'published',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          last_reply_at TIMESTAMP NULL,
          INDEX idx_author_id (author_id),
          INDEX idx_category_id (category_id),
          INDEX idx_status (status),
          INDEX idx_created_at (created_at),
          INDEX idx_last_reply_at (last_reply_at),
          INDEX idx_is_pinned (is_pinned),
          INDEX idx_is_featured (is_featured),
          FULLTEXT idx_fulltext (title, content),
          FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE CASCADE,
          FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      `)

      await execute(`
        CREATE TABLE IF NOT EXISTS discussion_tags (
          discussion_id BIGINT NOT NULL,
          tag_name VARCHAR(50) NOT NULL,
          PRIMARY KEY (discussion_id, tag_name),
          INDEX idx_tag_name (tag_name),
          FOREIGN KEY (discussion_id) REFERENCES discussions(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      `)

      await execute(`
        CREATE TABLE IF NOT EXISTS discussion_replies (
          id BIGINT PRIMARY KEY AUTO_INCREMENT,
          discussion_id BIGINT NOT NULL,
          author_id BIGINT NOT NULL,
          content TEXT NOT NULL,
          parent_id BIGINT,
          likes_count INT DEFAULT 0,
          is_accepted BOOLEAN DEFAULT FALSE,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          INDEX idx_discussion_id (discussion_id),
          INDEX idx_author_id (author_id),
          INDEX idx_parent_id (parent_id),
          INDEX idx_created_at (created_at),
          FOREIGN KEY (discussion_id) REFERENCES discussions(id) ON DELETE CASCADE,
          FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE CASCADE,
          FOREIGN KEY (parent_id) REFERENCES discussion_replies(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      `)

      console.log("✅ 讨论表创建成功")
    }

    // 尝试修改 likes 表以支持讨论和回复点赞
    try {
      await execute(`
        ALTER TABLE likes 
        MODIFY COLUMN target_type ENUM('term', 'paper', 'comment', 'discussion', 'discussion_reply') NOT NULL
      `)
    } catch (error: any) {
      // 如果修改失败（可能因为列已存在或表不存在），忽略错误
      if (
        !error.message?.includes("Duplicate column name") &&
        !error.message?.includes("does not exist") &&
        !error.message?.includes("Unknown column")
      ) {
        console.warn("⚠️  无法修改 likes 表:", error.message)
      }
    }
  } catch (error: any) {
    // 如果 users 表不存在，外键约束会失败，这是正常的
    if (error.code === "ER_NO_REFERENCED_ROW_2" || error.code === "ER_CANNOT_ADD_FOREIGN") {
      console.warn("⚠️  无法创建讨论表：users 表可能不存在，请先运行数据库初始化脚本")
    } else {
      console.error("检查讨论表时出错:", error.message)
    }
  }
}

export async function ensurePaymentCodesColumns(): Promise<void> {
  try {
    console.log("[ensurePaymentCodesColumns] Checking payment code columns...")
    
    // 检查字段是否存在
    const result = await query<{ count: number }>(
      `SELECT COUNT(*) as count 
       FROM information_schema.columns 
       WHERE table_schema = ? AND table_name = 'users' AND column_name = 'wechat_qr_code'`,
      [dbConfig.database]
    )

    console.log("[ensurePaymentCodesColumns] Column check result:", result)

    if (result.length === 0 || result[0].count === 0) {
      // 字段不存在，添加它们
      console.log("[ensurePaymentCodesColumns] Payment code columns not found, adding them...")
      try {
        await execute(`
          ALTER TABLE users
          ADD COLUMN wechat_qr_code VARCHAR(500) DEFAULT NULL COMMENT '微信收款码URL',
          ADD COLUMN alipay_qr_code VARCHAR(500) DEFAULT NULL COMMENT '支付宝收款码URL'
        `)
        console.log("[ensurePaymentCodesColumns] ✅ Payment code columns added successfully")
      } catch (alterError: any) {
        // 如果字段已存在（可能在其他地方创建了），忽略错误
        if (alterError.code === "ER_DUP_FIELDNAME") {
          console.log("[ensurePaymentCodesColumns] Columns already exist, skipping")
        } else {
          console.error("[ensurePaymentCodesColumns] Failed to add columns:", alterError)
          throw alterError
        }
      }
    } else {
      console.log("[ensurePaymentCodesColumns] ✅ Payment code columns already exist")
    }
  } catch (error: any) {
    // 如果表不存在，这是正常的（可能在初始化过程中）
    if (error.code === "ER_NO_SUCH_TABLE" || error.message?.includes("does not exist")) {
      console.warn("[ensurePaymentCodesColumns] Users table does not exist yet, skipping column check")
      return
    }
    
    // 如果是字段已存在的错误，忽略
    if (error.code === "ER_DUP_FIELDNAME" || error.message?.includes("Duplicate column name")) {
      console.log("[ensurePaymentCodesColumns] Columns already exist, skipping")
      return
    }
    
    // 其他错误需要记录
    console.error("[ensurePaymentCodesColumns] Error checking/adding payment code columns:", error)
    throw error
  }
}

export async function ensureBookmarksTable(): Promise<void> {
  try {
    // 检查表是否存在
    const result = await query<{ count: number }>(
      `SELECT COUNT(*) as count 
       FROM information_schema.tables 
       WHERE table_schema = ? AND table_name = 'bookmarks'`,
      [dbConfig.database]
    )

    if (result.length === 0 || result[0].count === 0) {
      // 表不存在，创建它
      console.log("检测到 bookmarks 表不存在，正在创建...")
      await execute(`
        CREATE TABLE IF NOT EXISTS bookmarks (
          id BIGINT PRIMARY KEY AUTO_INCREMENT,
          user_id BIGINT NOT NULL,
          target_type ENUM('term', 'paper') NOT NULL,
          target_id BIGINT NOT NULL,
          folder_name VARCHAR(100) DEFAULT 'default',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          UNIQUE KEY uk_user_target (user_id, target_type, target_id),
          INDEX idx_user_id (user_id),
          INDEX idx_target (target_type, target_id),
          INDEX idx_folder (user_id, folder_name),
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      `)
      console.log("✅ bookmarks 表创建成功")
    }
  } catch (error: any) {
    // 如果 users 表不存在，外键约束会失败，这是正常的
    if (error.code === "ER_NO_REFERENCED_ROW_2" || error.code === "ER_CANNOT_ADD_FOREIGN") {
      console.warn("⚠️  无法创建 bookmarks 表：users 表可能不存在，请先运行数据库初始化脚本")
    } else {
      console.error("检查 bookmarks 表时出错:", error.message)
    }
  }
}

export async function ensureDislikesTable(): Promise<void> {
  try {
    // 检查 dislikes 表是否存在
    const tableResult = await query<{ count: number }>(
      `SELECT COUNT(*) as count 
       FROM information_schema.tables 
       WHERE table_schema = ? AND table_name = 'dislikes'`,
      [dbConfig.database]
    )

    if (tableResult.length === 0 || tableResult[0].count === 0) {
      // 表不存在，创建它
      console.log("检测到 dislikes 表不存在，正在创建...")
      await execute(`
        CREATE TABLE IF NOT EXISTS dislikes (
          id BIGINT PRIMARY KEY AUTO_INCREMENT,
          user_id BIGINT NOT NULL,
          target_type ENUM('term', 'paper', 'comment') NOT NULL,
          target_id BIGINT NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          UNIQUE KEY uk_user_target (user_id, target_type, target_id),
          INDEX idx_user_id (user_id),
          INDEX idx_target (target_type, target_id),
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      `)
      console.log("✅ dislikes 表创建成功")
    }

    // 检查 terms 表中的 dislikes_count 字段是否存在
    try {
      const columnResult = await query<{ count: number }>(
        `SELECT COUNT(*) as count 
         FROM information_schema.columns 
         WHERE table_schema = ? AND table_name = 'terms' AND column_name = 'dislikes_count'`,
        [dbConfig.database]
      )

      if (columnResult.length === 0 || columnResult[0].count === 0) {
        // 字段不存在，添加它
        console.log("检测到 terms.dislikes_count 字段不存在，正在添加...")
        await execute(`
          ALTER TABLE terms 
          ADD COLUMN dislikes_count INT DEFAULT 0
        `)
        console.log("✅ terms.dislikes_count 字段添加成功")
      }
    } catch (error: any) {
      // 如果字段已存在或其他错误，忽略
      if (
        !error.message?.includes("Duplicate column name") &&
        !error.message?.includes("does not exist") &&
        !error.message?.includes("Unknown column")
      ) {
        console.warn("⚠️  无法添加 dislikes_count 字段:", error.message)
      }
    }
  } catch (error: any) {
    // 如果 users 表不存在，外键约束会失败，这是正常的
    if (error.code === "ER_NO_REFERENCED_ROW_2" || error.code === "ER_CANNOT_ADD_FOREIGN") {
      console.warn("⚠️  无法创建 dislikes 表：users 表可能不存在，请先运行数据库初始化脚本")
    } else {
      console.error("检查 dislikes 表时出错:", error.message)
    }
  }
}

export async function ensureAnnotationsTable(): Promise<void> {
  try {
    // 检查表是否存在
    const result = await query<{ count: number }>(
      `SELECT COUNT(*) as count 
       FROM information_schema.tables 
       WHERE table_schema = ? AND table_name = 'annotations'`,
      [dbConfig.database]
    )

    if (result.length === 0 || result[0].count === 0) {
      // 表不存在，创建它
      console.log("检测到 annotations 表不存在，正在创建...")
      await execute(`
        CREATE TABLE IF NOT EXISTS annotations (
          id BIGINT PRIMARY KEY AUTO_INCREMENT,
          user_id BIGINT NOT NULL,
          term_id BIGINT NOT NULL,
          target_type ENUM('term', 'paper') NOT NULL DEFAULT 'term',
          selected_text TEXT NOT NULL,
          start_offset INT NOT NULL,
          end_offset INT NOT NULL,
          color VARCHAR(20) DEFAULT 'yellow',
          note TEXT,
          tags JSON,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          INDEX idx_user_id (user_id),
          INDEX idx_term_id (term_id),
          INDEX idx_target (target_type, term_id),
          INDEX idx_user_term (user_id, term_id),
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
          FOREIGN KEY (term_id) REFERENCES terms(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      `)
      console.log("✅ annotations 表创建成功")
    }
  } catch (error: any) {
    // 如果 users 或 terms 表不存在，外键约束会失败，这是正常的
    if (error.code === "ER_NO_REFERENCED_ROW_2" || error.code === "ER_CANNOT_ADD_FOREIGN") {
      console.warn("⚠️  无法创建 annotations 表：users 或 terms 表可能不存在，请先运行数据库初始化脚本")
    } else {
      console.error("检查 annotations 表时出错:", error.message)
    }
  }
}
