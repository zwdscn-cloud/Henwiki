-- 添加广告管理权限
INSERT INTO permissions (code, name, description, module, resource, action) VALUES
('admin.ads.view', '查看广告列表', '可以查看广告列表', 'admin', 'ads', 'view'),
('admin.ads.create', '创建广告', '可以创建新广告', 'admin', 'ads', 'create'),
('admin.ads.edit', '编辑广告', '可以编辑广告内容', 'admin', 'ads', 'edit'),
('admin.ads.delete', '删除广告', '可以删除广告', 'admin', 'ads', 'delete')
ON DUPLICATE KEY UPDATE name=VALUES(name), description=VALUES(description);

-- 为管理员角色添加广告管理权限
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r, permissions p
WHERE r.code = 'admin'
AND p.code IN (
  'admin.ads.view',
  'admin.ads.create',
  'admin.ads.edit',
  'admin.ads.delete'
)
ON DUPLICATE KEY UPDATE role_id=VALUES(role_id);

-- 为高级管理员角色添加广告管理权限
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r, permissions p
WHERE r.code = 'super_admin'
AND p.code IN (
  'admin.ads.view',
  'admin.ads.create',
  'admin.ads.edit',
  'admin.ads.delete'
)
ON DUPLICATE KEY UPDATE role_id=VALUES(role_id);
