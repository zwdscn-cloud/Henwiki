-- 添加用户角色字段
ALTER TABLE users
ADD COLUMN role ENUM('user', 'admin') DEFAULT 'user' NOT NULL COMMENT '用户角色：user-普通用户，admin-管理员';

-- 将admin@gaoneng.wiki设置为管理员
UPDATE users SET role = 'admin' WHERE email = 'admin@gaoneng.wiki';

-- 添加索引以便快速查询管理员
CREATE INDEX idx_role ON users(role);
