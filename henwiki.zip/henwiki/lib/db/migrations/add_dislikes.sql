-- 创建踩表
CREATE TABLE IF NOT EXISTS dislikes (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id BIGINT NOT NULL,
  target_type ENUM('term', 'paper', 'comment') NOT NULL,
  target_id BIGINT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_user_target (user_id, target_type, target_id),
  INDEX idx_user_id (user_id),
  INDEX idx_target (target_type, target_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 为词条表添加踩数字段（如果不存在）
-- 注意：MySQL 8.0.19+ 支持 IF NOT EXISTS，旧版本需要手动检查
ALTER TABLE terms 
ADD COLUMN dislikes_count INT DEFAULT 0;
