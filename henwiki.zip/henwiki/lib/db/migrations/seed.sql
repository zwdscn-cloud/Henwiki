-- 数据库种子脚本 - 插入示例数据
USE henwiki;

-- 插入示例用户（密码都是 123456）
-- 密码哈希使用 bcrypt，这里需要先通过应用生成，暂时使用占位符
-- 实际使用时需要通过注册接口或脚本生成正确的密码哈希

-- 注意：以下密码哈希是对 "123456" 使用 bcrypt 生成的
-- 如果需要不同的密码，请使用应用中的 hashPassword 函数生成

-- 示例用户 1: 管理员/研究员
INSERT INTO users (email, password_hash, name, avatar, bio, points, level, contributions, followers_count, following_count, streak, is_verified, joined_at) VALUES
('admin@gaoneng.wiki', '$2a$10$rOzJqZqZqZqZqZqZqZqZqOZqZqZqZqZqZqZqZqZqZqZqZqZqZqZ', 'AI研究员', '/ai-researcher-avatar.jpg', '专注于大语言模型和AGI研究', 2580, 5, 42, 128, 56, 7, TRUE, '2023-06-15 10:00:00')
ON DUPLICATE KEY UPDATE email=email;

-- 示例用户 2: 材料科学家
INSERT INTO users (email, password_hash, name, avatar, bio, points, level, contributions, followers_count, following_count, streak, is_verified, joined_at) VALUES
('scientist@gaoneng.wiki', '$2a$10$rOzJqZqZqZqZqZqZqZqZqOZqZqZqZqZqZqZqZqZqZqZqZqZqZqZ', '材料科学家', '/material-scientist-avatar.jpg', '材料科学与物理学交叉研究', 1890, 4, 28, 89, 34, 5, TRUE, '2023-03-20 14:30:00')
ON DUPLICATE KEY UPDATE email=email;

-- 示例用户 3: 科技编辑
INSERT INTO users (email, password_hash, name, avatar, bio, points, level, contributions, followers_count, following_count, streak, is_verified, joined_at) VALUES
('editor@gaoneng.wiki', '$2a$10$rOzJqZqZqZqZqZqZqZqZqOZqZqZqZqZqZqZqZqZqZqZqZqZqZqZ', '科技编辑', '/tech-editor-avatar.jpg', '专注于AI和科技报道', 2150, 4, 35, 156, 78, 3, TRUE, '2022-11-08 09:15:00')
ON DUPLICATE KEY UPDATE email=email;

-- 获取用户ID（用于后续关联数据）
SET @user1_id = (SELECT id FROM users WHERE email = 'admin@gaoneng.wiki' LIMIT 1);
SET @user2_id = (SELECT id FROM users WHERE email = 'scientist@gaoneng.wiki' LIMIT 1);
SET @user3_id = (SELECT id FROM users WHERE email = 'editor@gaoneng.wiki' LIMIT 1);

-- 插入用户徽章
INSERT INTO user_badges (user_id, badge_id, badge_name, icon, description, earned_at) VALUES
(@user1_id, 'b1', '知识先锋', '🏆', '贡献超过10个词条', '2024-01-01 10:00:00'),
(@user1_id, 'b2', '活跃达人', '🔥', '连续签到7天', '2024-01-10 10:00:00'),
(@user1_id, 'b3', '精选作者', '⭐', '词条被收录为精选', '2024-01-15 10:00:00'),
(@user2_id, 'b1', '知识先锋', '🏆', '贡献超过10个词条', '2024-01-05 10:00:00'),
(@user3_id, 'b1', '知识先锋', '🏆', '贡献超过10个词条', '2024-01-08 10:00:00')
ON DUPLICATE KEY UPDATE user_id=user_id;

-- 插入用户专业领域
INSERT INTO user_specialties (user_id, specialty) VALUES
(@user1_id, '人工智能'),
(@user1_id, '量子计算'),
(@user2_id, '超导'),
(@user2_id, '纳米材料'),
(@user3_id, '科技新闻'),
(@user3_id, '产业分析')
ON DUPLICATE KEY UPDATE user_id=user_id;

-- 获取分类ID
SET @ai_category_id = (SELECT id FROM categories WHERE slug = 'ai' LIMIT 1);
SET @materials_category_id = (SELECT id FROM categories WHERE slug = 'materials' LIMIT 1);
SET @semiconductor_category_id = (SELECT id FROM categories WHERE slug = 'semiconductor' LIMIT 1);

-- 插入示例词条
INSERT INTO terms (title, category_id, summary, content, author_id, views, likes_count, comments_count, is_verified, status, created_at) VALUES
('GPT-5', @ai_category_id, 'GPT-5 是 OpenAI 预计于 2024-2025 年发布的下一代大型语言模型。相比 GPT-4，GPT-5 预计将在推理能力、多模态理解、代码生成等方面实现重大突破，并可能具备更强的自主学习和规划能力。', 
'## 概述\n\nGPT-5 是 OpenAI 正在开发的下一代大型语言模型（LLM），作为 GPT-4 的继任者，预计将在 2024-2025 年间发布。根据业内消息和 OpenAI 的技术路线图，GPT-5 将在多个关键领域实现突破性进展。\n\n## 技术特点\n\n### 1. 增强的推理能力\n- **多步骤推理**：能够进行更复杂的逻辑链条推理\n- **数学证明**：在形式化数学推理方面大幅提升\n- **因果推断**：更好地理解事件之间的因果关系\n\n### 2. 多模态融合\n- 深度整合文本、图像、音频、视频理解\n- 原生支持实时视觉理解和交互\n- 跨模态推理和生成能力', @user1_id, 12500, 856, 124, TRUE, 'published', '2024-01-15 10:00:00'),
('室温超导体 LK-99', @materials_category_id, 'LK-99 是一种铅-磷灰石结构的材料，由韩国研究团队声称在常压室温下表现出超导特性。如果得到验证，这将是材料科学的革命性突破。',
'## 概述\n\nLK-99 是由韩国研究团队于 2023 年声称发现的一种可能在室温和常压下表现出超导特性的材料。这种材料基于铅-磷灰石结构，如果得到验证，将是超导领域的革命性突破。\n\n## 材料结构\n\nLK-99 的化学式为 Pb₁₀₋ₓCuₓ(PO₄)₆O，其中部分铅原子被铜原子取代。研究者声称这种结构会产生内部应力，从而导致超导特性。', @user2_id, 45000, 2341, 567, FALSE, 'published', '2024-01-14 15:30:00'),
('神经形态计算', @semiconductor_category_id, '神经形态计算是一种模仿人脑神经网络结构的计算范式。通过使用专门设计的神经形态芯片，可以实现比传统冯·诺依曼架构更高效的AI推理，能耗降低数个数量级。',
'## 概述\n\n神经形态计算（Neuromorphic Computing）是一种受人脑结构和功能启发的计算范式，旨在通过模仿生物神经网络的信息处理方式来实现更高效的计算。', @user1_id, 8900, 623, 87, TRUE, 'published', '2024-01-12 09:20:00')
ON DUPLICATE KEY UPDATE title=title;

-- 获取词条ID
SET @term1_id = (SELECT id FROM terms WHERE title = 'GPT-5' LIMIT 1);
SET @term2_id = (SELECT id FROM terms WHERE title = '室温超导体 LK-99' LIMIT 1);
SET @term3_id = (SELECT id FROM terms WHERE title = '神经形态计算' LIMIT 1);

-- 插入词条标签
INSERT INTO term_tags (term_id, tag_name) VALUES
(@term1_id, 'AGI'),
(@term1_id, '大语言模型'),
(@term1_id, 'OpenAI'),
(@term2_id, '超导'),
(@term2_id, '材料科学'),
(@term2_id, '能源革命'),
(@term3_id, '类脑计算'),
(@term3_id, 'AI芯片'),
(@term3_id, '低功耗')
ON DUPLICATE KEY UPDATE term_id=term_id;

-- 插入示例评论
INSERT INTO comments (term_id, author_id, content, parent_id, likes_count, created_at) VALUES
(@term1_id, @user2_id, 'GPT-5 如果真能实现这些能力，将会对科研工作产生巨大影响。期待能用它来辅助材料设计！', NULL, 45, '2024-01-15 11:00:00'),
(@term1_id, @user1_id, '是的，AI for Science 正在成为一个重要的研究方向。', @term1_id, 12, '2024-01-15 11:30:00'),
(@term1_id, @user3_id, '从技术演进的角度来看，GPT-5 的发布时间可能会比预期更晚，因为算力和安全性的挑战都很大。', NULL, 32, '2024-01-15 12:00:00')
ON DUPLICATE KEY UPDATE content=content;
