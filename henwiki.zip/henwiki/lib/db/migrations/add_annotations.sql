-- 添加标记和笔记表
CREATE TABLE IF NOT EXISTS annotations (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id BIGINT NOT NULL,
  term_id BIGINT NOT NULL,
  target_type ENUM('term', 'paper') NOT NULL DEFAULT 'term',
  selected_text TEXT NOT NULL,
  start_offset INT NOT NULL,
  end_offset INT NOT NULL,
  color VARCHAR(20) DEFAULT 'yellow',
  note TEXT,
  tags JSON,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_user_id (user_id),
  INDEX idx_term_id (term_id),
  INDEX idx_target (target_type, term_id),
  INDEX idx_user_term (user_id, term_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (term_id) REFERENCES terms(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
