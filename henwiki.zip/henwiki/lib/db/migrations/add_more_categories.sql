-- 添加更多领域分类
USE henwiki;

INSERT INTO categories (slug, label, description, color, count) VALUES
('robotics', '机器人学', '工业机器人、服务机器人、人形机器人等机器人技术', 'bg-indigo-500', 0),
('autonomous', '自动驾驶', '无人驾驶汽车、自动驾驶技术、智能交通系统', 'bg-blue-600', 0),
('biomedical', '生物医学工程', '医疗设备、生物材料、组织工程、再生医学', 'bg-rose-500', 0),
('environment', '环境科学', '气候变化、污染治理、可持续发展、绿色技术', 'bg-emerald-500', 0),
('data-science', '数据科学', '大数据分析、机器学习、数据挖掘、商业智能', 'bg-violet-500', 0),
('cloud-computing', '云计算', '云服务、分布式计算、容器技术、微服务架构', 'bg-sky-500', 0),
('edge-computing', '边缘计算', '边缘设备、实时计算、IoT边缘处理、5G边缘', 'bg-amber-500', 0),
('iot', '物联网', '智能家居、工业物联网、传感器网络、万物互联', 'bg-lime-500', 0),
('telecom', '通信技术', '5G/6G网络、卫星通信、光通信、无线技术', 'bg-fuchsia-500', 0),
('nanotech', '纳米技术', '纳米材料、纳米器件、纳米医学、分子制造', 'bg-cyan-600', 0),
('aerospace', '航空航天', '商用航空、无人机、卫星技术、太空探索', 'bg-orange-600', 0),
('marine', '海洋科技', '深海探测、海洋能源、海水淡化、海洋生物技术', 'bg-blue-500', 0),
('agriculture', '农业科技', '精准农业、基因改良作物、农业机器人、垂直农业', 'bg-green-600', 0),
('fintech', '金融科技', '数字货币、区块链金融、智能投顾、支付创新', 'bg-yellow-600', 0),
('healthtech', '医疗科技', '数字医疗、远程医疗、AI诊断、可穿戴医疗设备', 'bg-red-500', 0),
('edtech', '教育科技', '在线教育、AI教学、虚拟教室、个性化学习', 'bg-purple-600', 0),
('foodtech', '食品科技', '人造肉、3D打印食品、食品工程、营养科学', 'bg-orange-500', 0),
('fashiontech', '时尚科技', '智能服装、可穿戴设备、3D打印服装、可持续时尚', 'bg-pink-600', 0),
('sportstech', '体育科技', '运动数据分析、智能训练、运动装备创新、电子竞技', 'bg-red-600', 0),
('architech', '建筑科技', '智能建筑、3D打印建筑、绿色建筑、建筑信息模型', 'bg-stone-500', 0)
ON DUPLICATE KEY UPDATE label=VALUES(label), description=VALUES(description), color=VALUES(color);
