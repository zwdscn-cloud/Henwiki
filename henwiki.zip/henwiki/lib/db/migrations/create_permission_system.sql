-- 权限管理系统迁移
-- 创建完整的基于数据库的权限管理系统

USE henwiki;

-- 1. 权限表
CREATE TABLE IF NOT EXISTS permissions (
  id INT PRIMARY KEY AUTO_INCREMENT,
  code VARCHAR(100) UNIQUE NOT NULL COMMENT '权限代码，如 admin.users.view',
  name VARCHAR(200) NOT NULL COMMENT '权限名称',
  description TEXT COMMENT '权限描述',
  module VARCHAR(50) NOT NULL COMMENT '所属模块',
  resource VARCHAR(50) NOT NULL COMMENT '资源名称',
  action VARCHAR(50) NOT NULL COMMENT '操作类型',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_code (code),
  INDEX idx_module (module),
  INDEX idx_resource (resource)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. 角色表
CREATE TABLE IF NOT EXISTS roles (
  id INT PRIMARY KEY AUTO_INCREMENT,
  code VARCHAR(50) UNIQUE NOT NULL COMMENT '角色代码',
  name VARCHAR(100) NOT NULL COMMENT '角色名称',
  description TEXT COMMENT '角色描述',
  level INT DEFAULT 0 COMMENT '角色等级，数字越大权限越高',
  is_system BOOLEAN DEFAULT FALSE COMMENT '是否为系统角色，系统角色不可删除',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_code (code),
  INDEX idx_level (level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. 角色权限关联表
CREATE TABLE IF NOT EXISTS role_permissions (
  role_id INT NOT NULL,
  permission_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (role_id, permission_id),
  FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
  FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE,
  INDEX idx_role_id (role_id),
  INDEX idx_permission_id (permission_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. 用户角色关联表
CREATE TABLE IF NOT EXISTS user_roles (
  user_id BIGINT NOT NULL,
  role_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, role_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
  INDEX idx_user_id (user_id),
  INDEX idx_role_id (role_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. 插入权限数据
INSERT INTO permissions (code, name, description, module, resource, action) VALUES
-- 后台访问权限
('admin.dashboard.view', '查看后台仪表盘', '可以访问后台管理首页', 'admin', 'dashboard', 'view'),
('admin.stats.view', '查看统计数据', '可以查看后台统计数据', 'admin', 'stats', 'view'),

-- 用户管理权限
('admin.users.view', '查看用户列表', '可以查看用户列表', 'admin', 'users', 'view'),
('admin.users.edit', '编辑用户信息', '可以编辑用户信息', 'admin', 'users', 'edit'),
('admin.users.delete', '删除用户', '可以删除用户账号', 'admin', 'users', 'delete'),
('admin.users.role.assign', '分配用户角色', '可以为用户分配角色', 'admin', 'users', 'role.assign'),

-- 词条管理权限
('admin.terms.view', '查看词条列表', '可以查看词条列表', 'admin', 'terms', 'view'),
('admin.terms.edit', '编辑词条', '可以编辑词条内容', 'admin', 'terms', 'edit'),
('admin.terms.delete', '删除词条', '可以删除词条', 'admin', 'terms', 'delete'),
('admin.terms.approve', '审核通过词条', '可以审核通过词条', 'admin', 'terms', 'approve'),
('admin.terms.reject', '审核拒绝词条', '可以审核拒绝词条', 'admin', 'terms', 'reject'),

-- 论文管理权限
('admin.papers.view', '查看论文列表', '可以查看论文列表', 'admin', 'papers', 'view'),
('admin.papers.edit', '编辑论文', '可以编辑论文内容', 'admin', 'papers', 'edit'),
('admin.papers.delete', '删除论文', '可以删除论文', 'admin', 'papers', 'delete'),
('admin.papers.approve', '审核通过论文', '可以审核通过论文', 'admin', 'papers', 'approve'),
('admin.papers.reject', '审核拒绝论文', '可以审核拒绝论文', 'admin', 'papers', 'reject'),

-- 评论管理权限
('admin.comments.view', '查看评论列表', '可以查看评论列表', 'admin', 'comments', 'view'),
('admin.comments.delete', '删除评论', '可以删除评论', 'admin', 'comments', 'delete'),

-- 审核管理权限
('admin.review.view', '查看待审核内容', '可以查看待审核的内容列表', 'admin', 'review', 'view'),
('admin.review.approve', '审核通过', '可以审核通过内容', 'admin', 'review', 'approve'),
('admin.review.reject', '审核拒绝', '可以审核拒绝内容', 'admin', 'review', 'reject'),

-- 数据分析权限
('admin.analytics.view', '查看数据分析', '可以查看数据分析报表', 'admin', 'analytics', 'view'),

-- 系统设置权限
('admin.settings.view', '查看系统设置', '可以查看系统设置', 'admin', 'settings', 'view'),
('admin.settings.edit', '编辑系统设置', '可以编辑系统设置', 'admin', 'settings', 'edit'),

-- 角色权限管理权限
('admin.roles.view', '查看角色列表', '可以查看角色列表', 'admin', 'roles', 'view'),
('admin.roles.edit', '编辑角色', '可以编辑角色信息', 'admin', 'roles', 'edit'),
('admin.roles.create', '创建角色', '可以创建新角色', 'admin', 'roles', 'create'),
('admin.roles.delete', '删除角色', '可以删除角色', 'admin', 'roles', 'delete'),
('admin.permissions.manage', '管理权限清单', '可以管理权限清单', 'admin', 'permissions', 'manage')
ON DUPLICATE KEY UPDATE name=VALUES(name), description=VALUES(description);

-- 6. 插入角色数据
INSERT INTO roles (code, name, description, level, is_system) VALUES
('user', '普通用户', '普通注册用户，无后台权限', 0, TRUE),
('moderator', '版主', '负责内容审核和评论管理', 1, TRUE),
('admin', '管理员', '拥有大部分后台管理权限', 2, TRUE),
('super_admin', '高级管理员', '拥有所有权限，包括角色权限管理', 3, TRUE)
ON DUPLICATE KEY UPDATE name=VALUES(name), description=VALUES(description);

-- 7. 建立角色权限关联
-- 版主权限
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r, permissions p
WHERE r.code = 'moderator'
AND p.code IN (
  'admin.dashboard.view',
  'admin.review.view',
  'admin.review.approve',
  'admin.review.reject',
  'admin.comments.view',
  'admin.comments.delete'
)
ON DUPLICATE KEY UPDATE role_id=VALUES(role_id);

-- 管理员权限（包含版主所有权限）
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r, permissions p
WHERE r.code = 'admin'
AND p.code IN (
  'admin.dashboard.view',
  'admin.stats.view',
  'admin.users.view',
  'admin.users.edit',
  'admin.terms.view',
  'admin.terms.edit',
  'admin.terms.delete',
  'admin.terms.approve',
  'admin.terms.reject',
  'admin.papers.view',
  'admin.papers.edit',
  'admin.papers.delete',
  'admin.papers.approve',
  'admin.papers.reject',
  'admin.comments.view',
  'admin.comments.delete',
  'admin.review.view',
  'admin.review.approve',
  'admin.review.reject',
  'admin.analytics.view',
  'admin.settings.view'
)
ON DUPLICATE KEY UPDATE role_id=VALUES(role_id);

-- 高级管理员权限（包含管理员所有权限）
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r, permissions p
WHERE r.code = 'super_admin'
AND p.code IN (
  'admin.dashboard.view',
  'admin.stats.view',
  'admin.users.view',
  'admin.users.edit',
  'admin.users.delete',
  'admin.users.role.assign',
  'admin.terms.view',
  'admin.terms.edit',
  'admin.terms.delete',
  'admin.terms.approve',
  'admin.terms.reject',
  'admin.papers.view',
  'admin.papers.edit',
  'admin.papers.delete',
  'admin.papers.approve',
  'admin.papers.reject',
  'admin.comments.view',
  'admin.comments.delete',
  'admin.review.view',
  'admin.review.approve',
  'admin.review.reject',
  'admin.analytics.view',
  'admin.settings.view',
  'admin.settings.edit',
  'admin.roles.view',
  'admin.roles.edit',
  'admin.roles.create',
  'admin.roles.delete',
  'admin.permissions.manage'
)
ON DUPLICATE KEY UPDATE role_id=VALUES(role_id);

-- 8. 为现有管理员用户分配角色
-- 将 role='admin' 的用户分配为 super_admin 角色（可以根据需要调整）
INSERT INTO user_roles (user_id, role_id)
SELECT u.id, r.id
FROM users u, roles r
WHERE u.role = 'admin' AND r.code = 'super_admin'
ON DUPLICATE KEY UPDATE user_id=VALUES(user_id);

-- 为普通用户分配 user 角色
INSERT INTO user_roles (user_id, role_id)
SELECT u.id, r.id
FROM users u, roles r
WHERE (u.role = 'user' OR u.role IS NULL) AND r.code = 'user'
AND NOT EXISTS (
  SELECT 1 FROM user_roles ur WHERE ur.user_id = u.id
)
ON DUPLICATE KEY UPDATE user_id=VALUES(user_id);
