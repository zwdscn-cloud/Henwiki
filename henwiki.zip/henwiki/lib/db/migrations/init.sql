-- 创建数据库（如果不存在）
CREATE DATABASE IF NOT EXISTS henwiki CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE henwiki;

-- 1. 用户表
CREATE TABLE IF NOT EXISTS users (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  name VARCHAR(100) NOT NULL,
  avatar VARCHAR(500) DEFAULT '',
  bio TEXT,
  points INT DEFAULT 0,
  level INT DEFAULT 1,
  contributions INT DEFAULT 0,
  followers_count INT DEFAULT 0,
  following_count INT DEFAULT 0,
  streak INT DEFAULT 0,
  last_check_in DATE,
  is_verified BOOLEAN DEFAULT FALSE,
  joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_email (email),
  INDEX idx_points (points),
  INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. 分类表
CREATE TABLE IF NOT EXISTS categories (
  id INT PRIMARY KEY AUTO_INCREMENT,
  slug VARCHAR(50) UNIQUE NOT NULL,
  label VARCHAR(100) NOT NULL,
  description TEXT,
  color VARCHAR(20) DEFAULT '',
  count INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. 词条表
CREATE TABLE IF NOT EXISTS terms (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(255) NOT NULL,
  category_id INT NOT NULL,
  summary TEXT,
  content LONGTEXT,
  author_id BIGINT NOT NULL,
  views INT DEFAULT 0,
  likes_count INT DEFAULT 0,
  dislikes_count INT DEFAULT 0,
  comments_count INT DEFAULT 0,
  is_verified BOOLEAN DEFAULT FALSE,
  status ENUM('draft', 'pending', 'published', 'rejected') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_title (title),
  INDEX idx_category_id (category_id),
  INDEX idx_author_id (author_id),
  INDEX idx_status (status),
  INDEX idx_created_at (created_at),
  INDEX idx_category_created (category_id, created_at),
  FULLTEXT idx_fulltext (title, content),
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT,
  FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. 词条标签关联表
CREATE TABLE IF NOT EXISTS term_tags (
  term_id BIGINT NOT NULL,
  tag_name VARCHAR(50) NOT NULL,
  PRIMARY KEY (term_id, tag_name),
  INDEX idx_tag_name (tag_name),
  FOREIGN KEY (term_id) REFERENCES terms(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. 论文表
CREATE TABLE IF NOT EXISTS papers (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(500) NOT NULL,
  title_cn VARCHAR(500),
  abstract TEXT,
  abstract_cn TEXT,
  category_id INT NOT NULL,
  journal VARCHAR(200),
  publish_date DATE,
  arxiv_id VARCHAR(50),
  doi VARCHAR(100),
  pdf_url VARCHAR(500),
  pdf_file_path VARCHAR(500),
  citations INT DEFAULT 0,
  views INT DEFAULT 0,
  downloads INT DEFAULT 0,
  likes_count INT DEFAULT 0,
  is_highlighted BOOLEAN DEFAULT FALSE,
  status ENUM('draft', 'pending', 'published') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_category_id (category_id),
  INDEX idx_publish_date (publish_date),
  INDEX idx_arxiv_id (arxiv_id),
  INDEX idx_doi (doi),
  INDEX idx_views (views),
  INDEX idx_status (status),
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. 论文作者表
CREATE TABLE IF NOT EXISTS paper_authors (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  paper_id BIGINT NOT NULL,
  name VARCHAR(200) NOT NULL,
  affiliation VARCHAR(300),
  order_index INT DEFAULT 0,
  INDEX idx_paper_id (paper_id),
  FOREIGN KEY (paper_id) REFERENCES papers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. 论文标签关联表
CREATE TABLE IF NOT EXISTS paper_tags (
  paper_id BIGINT NOT NULL,
  tag_name VARCHAR(50) NOT NULL,
  PRIMARY KEY (paper_id, tag_name),
  FOREIGN KEY (paper_id) REFERENCES papers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. 评论表
CREATE TABLE IF NOT EXISTS comments (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  term_id BIGINT NOT NULL,
  author_id BIGINT NOT NULL,
  content TEXT NOT NULL,
  parent_id BIGINT,
  likes_count INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_term_id (term_id),
  INDEX idx_author_id (author_id),
  INDEX idx_parent_id (parent_id),
  INDEX idx_created_at (created_at),
  FOREIGN KEY (term_id) REFERENCES terms(id) ON DELETE CASCADE,
  FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (parent_id) REFERENCES comments(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. 点赞表
CREATE TABLE IF NOT EXISTS likes (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id BIGINT NOT NULL,
  target_type ENUM('term', 'paper', 'comment') NOT NULL,
  target_id BIGINT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_user_target (user_id, target_type, target_id),
  INDEX idx_user_id (user_id),
  INDEX idx_target (target_type, target_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9.1. 踩表
CREATE TABLE IF NOT EXISTS dislikes (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id BIGINT NOT NULL,
  target_type ENUM('term', 'paper', 'comment') NOT NULL,
  target_id BIGINT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_user_target (user_id, target_type, target_id),
  INDEX idx_user_id (user_id),
  INDEX idx_target (target_type, target_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. 用户徽章表
CREATE TABLE IF NOT EXISTS user_badges (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id BIGINT NOT NULL,
  badge_id VARCHAR(50) NOT NULL,
  badge_name VARCHAR(100) NOT NULL,
  icon VARCHAR(20) DEFAULT '',
  description TEXT,
  earned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_user_id (user_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. 用户专业领域表
CREATE TABLE IF NOT EXISTS user_specialties (
  user_id BIGINT NOT NULL,
  specialty VARCHAR(50) NOT NULL,
  PRIMARY KEY (user_id, specialty),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12. 关注关系表
CREATE TABLE IF NOT EXISTS follows (
  follower_id BIGINT NOT NULL,
  following_id BIGINT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (follower_id, following_id),
  INDEX idx_follower_id (follower_id),
  INDEX idx_following_id (following_id),
  FOREIGN KEY (follower_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (following_id) REFERENCES users(id) ON DELETE CASCADE,
  CHECK (follower_id != following_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 13. 通知表
CREATE TABLE IF NOT EXISTS notifications (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id BIGINT NOT NULL,
  type ENUM('like', 'comment', 'follow', 'mention', 'system') NOT NULL,
  actor_id BIGINT,
  target_type VARCHAR(50),
  target_id BIGINT,
  content TEXT,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_user_id (user_id),
  INDEX idx_is_read (is_read),
  INDEX idx_created_at (created_at),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (actor_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 14. 期刊/会议表
CREATE TABLE IF NOT EXISTS journals (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(200) UNIQUE NOT NULL,
  impact_factor DECIMAL(5,2),
  count INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 15. 收藏表
CREATE TABLE IF NOT EXISTS bookmarks (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id BIGINT NOT NULL,
  target_type ENUM('term', 'paper') NOT NULL,
  target_id BIGINT NOT NULL,
  folder_name VARCHAR(100) DEFAULT 'default',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_user_target (user_id, target_type, target_id),
  INDEX idx_user_id (user_id),
  INDEX idx_target (target_type, target_id),
  INDEX idx_folder (user_id, folder_name),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 初始化分类数据
INSERT INTO categories (slug, label, description, color, count) VALUES
('ai', '人工智能', '机器学习、深度学习、大语言模型等AI前沿技术', 'bg-blue-500', 0),
('biotech', '生物科技', '基因编辑、合成生物学、脑机接口等生命科学技术', 'bg-green-500', 0),
('quantum', '量子计算', '量子比特、量子纠错、量子算法等量子技术', 'bg-purple-500', 0),
('space', '航天科技', '火箭发射、卫星系统、深空探测等航天技术', 'bg-orange-500', 0),
('energy', '新能源', '核聚变、氢能源、储能技术等清洁能源', 'bg-yellow-500', 0),
('semiconductor', '芯片半导体', '先进制程、芯片设计、封装技术等', 'bg-red-500', 0),
('metaverse', '元宇宙', 'VR/AR、数字孪生、虚拟经济等', 'bg-pink-500', 0),
('blockchain', '区块链', '加密货币、智能合约、Web3等', 'bg-cyan-500', 0),
('security', '网络安全', '加密技术、隐私保护、安全防护等', 'bg-slate-500', 0),
('materials', '材料科学', '超导材料、纳米材料、新型合金等', 'bg-teal-500', 0)
ON DUPLICATE KEY UPDATE label=VALUES(label);

-- 初始化期刊数据
INSERT INTO journals (name, impact_factor, count) VALUES
('Nature', 69.5, 0),
('Science', 63.7, 0),
('NeurIPS', NULL, 0),
('ICML', NULL, 0),
('CVPR', NULL, 0),
('arXiv', NULL, 0),
('Cell', 66.8, 0),
('Nature Physics', 20.6, 0)
ON DUPLICATE KEY UPDATE name=VALUES(name);
