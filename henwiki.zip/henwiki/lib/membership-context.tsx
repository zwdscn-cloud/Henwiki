"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

export type MembershipTier = "free" | "pro" | "enterprise"

export interface MembershipPlan {
  id: string
  tier: MembershipTier
  name: string
  price: { monthly: number; yearly: number }
  limits: {
    dailySearches: number
    dailyAIQueries: number
    bookmarks: number
    apiCalls: number
    pdfExports: number
  }
  features: string[]
}

export interface UserMembership {
  tier: MembershipTier
  startDate: string
  endDate: string
  isYearly: boolean
  autoRenew: boolean
}

interface MembershipContextType {
  membership: UserMembership | null
  plans: MembershipPlan[]
  isLoading: boolean
  usage: {
    searches: number
    aiQueries: number
    bookmarks: number
    apiCalls: number
    pdfExports: number
  }
  canUseFeature: (feature: string) => boolean
  getRemainingLimit: (limitType: keyof MembershipPlan["limits"]) => number
  upgradeMembership: (tier: MembershipTier, isYearly: boolean) => Promise<boolean>
  cancelMembership: () => Promise<boolean>
  trackUsage: (type: keyof MembershipContextType["usage"]) => void
}

export const membershipPlans: MembershipPlan[] = [
  {
    id: "free",
    tier: "free",
    name: "免费版",
    price: { monthly: 0, yearly: 0 },
    limits: {
      dailySearches: 20,
      dailyAIQueries: 3,
      bookmarks: 50,
      apiCalls: 0,
      pdfExports: 0,
    },
    features: ["浏览公开词条", "基础搜索", "有限收藏", "社区讨论"],
  },
  {
    id: "pro",
    tier: "pro",
    name: "Pro会员",
    price: { monthly: 29, yearly: 199 },
    limits: {
      dailySearches: -1,
      dailyAIQueries: 100,
      bookmarks: -1,
      apiCalls: 5000,
      pdfExports: 50,
    },
    features: [
      "无限搜索",
      "AI智能问答",
      "无限收藏",
      "PDF导出",
      "API访问",
      "高级筛选",
      "无广告体验",
      "优先客服",
    ],
  },
  {
    id: "enterprise",
    tier: "enterprise",
    name: "企业版",
    price: { monthly: 299, yearly: 2399 },
    limits: {
      dailySearches: -1,
      dailyAIQueries: -1,
      bookmarks: -1,
      apiCalls: -1,
      pdfExports: -1,
    },
    features: [
      "Pro全部功能",
      "无限API调用",
      "团队协作",
      "私有知识库",
      "SSO登录",
      "专属客户经理",
      "数据导出",
      "SLA保障",
    ],
  },
]

const MembershipContext = createContext<MembershipContextType | undefined>(undefined)

export function MembershipProvider({ children }: { children: React.ReactNode }) {
  const [membership, setMembership] = useState<UserMembership | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [usage, setUsage] = useState({
    searches: 0,
    aiQueries: 0,
    bookmarks: 12,
    apiCalls: 0,
    pdfExports: 0,
  })

  useEffect(() => {
    const savedMembership = localStorage.getItem("gaoneng_membership")
    if (savedMembership) {
      setMembership(JSON.parse(savedMembership))
    }
    
    const savedUsage = localStorage.getItem("gaoneng_usage")
    const today = new Date().toDateString()
    if (savedUsage) {
      const parsed = JSON.parse(savedUsage)
      if (parsed.date === today) {
        setUsage(parsed.usage)
      }
    }
    
    setIsLoading(false)
  }, [])

  const getCurrentPlan = (): MembershipPlan => {
    const tier = membership?.tier || "free"
    return membershipPlans.find((p) => p.tier === tier) || membershipPlans[0]
  }

  const canUseFeature = (feature: string): boolean => {
    const plan = getCurrentPlan()
    return plan.features.includes(feature) || plan.tier === "enterprise"
  }

  const getRemainingLimit = (limitType: keyof MembershipPlan["limits"]): number => {
    const plan = getCurrentPlan()
    const limit = plan.limits[limitType]
    if (limit === -1) return -1
    
    const usageMap: Record<string, number> = {
      dailySearches: usage.searches,
      dailyAIQueries: usage.aiQueries,
      bookmarks: usage.bookmarks,
      apiCalls: usage.apiCalls,
      pdfExports: usage.pdfExports,
    }
    
    return Math.max(0, limit - (usageMap[limitType] || 0))
  }

  const trackUsage = (type: keyof typeof usage) => {
    setUsage((prev) => {
      const newUsage = { ...prev, [type]: prev[type] + 1 }
      localStorage.setItem(
        "gaoneng_usage",
        JSON.stringify({ date: new Date().toDateString(), usage: newUsage })
      )
      return newUsage
    })
  }

  const upgradeMembership = async (tier: MembershipTier, isYearly: boolean): Promise<boolean> => {
    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 1500))
    
    const now = new Date()
    const endDate = new Date(now)
    if (isYearly) {
      endDate.setFullYear(endDate.getFullYear() + 1)
    } else {
      endDate.setMonth(endDate.getMonth() + 1)
    }
    
    const newMembership: UserMembership = {
      tier,
      startDate: now.toISOString(),
      endDate: endDate.toISOString(),
      isYearly,
      autoRenew: true,
    }
    
    setMembership(newMembership)
    localStorage.setItem("gaoneng_membership", JSON.stringify(newMembership))
    setIsLoading(false)
    return true
  }

  const cancelMembership = async (): Promise<boolean> => {
    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 1000))
    
    if (membership) {
      const updated = { ...membership, autoRenew: false }
      setMembership(updated)
      localStorage.setItem("gaoneng_membership", JSON.stringify(updated))
    }
    
    setIsLoading(false)
    return true
  }

  return (
    <MembershipContext.Provider
      value={{
        membership,
        plans: membershipPlans,
        isLoading,
        usage,
        canUseFeature,
        getRemainingLimit,
        upgradeMembership,
        cancelMembership,
        trackUsage,
      }}
    >
      {children}
    </MembershipContext.Provider>
  )
}

export function useMembership() {
  const context = useContext(MembershipContext)
  if (context === undefined) {
    throw new Error("useMembership must be used within a MembershipProvider")
  }
  return context
}
