// 共享的模拟数据
export const mockTerms = [
  {
    id: "1",
    title: "GPT-5",
    category: "人工智能",
    categorySlug: "ai",
    summary:
      "GPT-5 是 OpenAI 预计于 2024-2025 年发布的下一代大型语言模型。相比 GPT-4，GPT-5 预计将在推理能力、多模态理解、代码生成等方面实现重大突破，并可能具备更强的自主学习和规划能力。",
    content: `
## 概述

GPT-5 是 OpenAI 正在开发的下一代大型语言模型（LLM），作为 GPT-4 的继任者，预计将在 2024-2025 年间发布。根据业内消息和 OpenAI 的技术路线图，GPT-5 将在多个关键领域实现突破性进展。

## 技术特点

### 1. 增强的推理能力
- **多步骤推理**：能够进行更复杂的逻辑链条推理
- **数学证明**：在形式化数学推理方面大幅提升
- **因果推断**：更好地理解事件之间的因果关系

### 2. 多模态融合
- 深度整合文本、图像、音频、视频理解
- 原生支持实时视觉理解和交互
- 跨模态推理和生成能力

### 3. 长上下文处理
- 上下文窗口预计扩展到数十万甚至上百万 token
- 更好的长文档理解和总结能力

## 潜在应用

1. **科学研究助手**：辅助科学家进行假设生成和实验设计
2. **代码开发**：端到端的软件工程能力
3. **教育个性化**：定制化的学习体验
4. **医疗诊断**：辅助医生进行复杂病例分析

## 相关词条

- AGI（通用人工智能）
- 大语言模型
- Transformer 架构
- 涌现能力
    `,
    author: {
      id: "u1",
      name: "AI研究员",
      avatar: "/ai-researcher-avatar.jpg",
      bio: "专注于大语言模型和AGI研究",
      contributions: 234,
    },
    stats: { views: 12500, likes: 856, comments: 124 },
    tags: ["AGI", "大语言模型", "OpenAI"],
    createdAt: "2小时前",
    updatedAt: "2024-01-15",
    isVerified: true,
    references: [
      { title: "OpenAI Research", url: "https://openai.com/research" },
      { title: "GPT-4 Technical Report", url: "https://arxiv.org/abs/2303.08774" },
    ],
  },
  {
    id: "2",
    title: "室温超导体 LK-99",
    category: "材料科学",
    categorySlug: "materials",
    summary:
      "LK-99 是一种铅-磷灰石结构的材料，由韩国研究团队声称在常压室温下表现出超导特性。如果得到验证，这将是材料科学的革命性突破。",
    content: `
## 概述

LK-99 是由韩国研究团队于 2023 年声称发现的一种可能在室温和常压下表现出超导特性的材料。这种材料基于铅-磷灰石结构，如果得到验证，将是超导领域的革命性突破。

## 材料结构

LK-99 的化学式为 Pb₁₀₋ₓCuₓ(PO₄)₆O，其中部分铅原子被铜原子取代。研究者声称这种结构会产生内部应力，从而导致超导特性。

## 争议与验证

截至目前，全球多个实验室尝试复现 LK-99 的超导特性，结果各异：
- 部分实验观察到抗磁性
- 大多数复现实验未能确认超导特性
- 科学界仍在进行严格的验证工作

## 潜在影响

如果室温超导被证实：
1. 电力传输效率将大幅提升
2. 量子计算将更容易实现
3. 磁悬浮交通将变得更加实用
4. 医疗MRI设备成本将大幅降低
    `,
    author: {
      id: "u2",
      name: "材料科学家",
      avatar: "/material-scientist-avatar.jpg",
      bio: "材料科学与物理学交叉研究",
      contributions: 156,
    },
    stats: { views: 45000, likes: 2341, comments: 567 },
    tags: ["超导", "材料科学", "能源革命"],
    createdAt: "5小时前",
    updatedAt: "2024-01-14",
    isVerified: false,
    references: [{ title: "arXiv预印本", url: "https://arxiv.org" }],
  },
  {
    id: "3",
    title: "Sora",
    category: "人工智能",
    categorySlug: "ai",
    summary: "Sora 是 OpenAI 开发的文本到视频生成模型，能够根据文本描述生成长达一分钟的高质量视频。",
    content: `
## 概述

Sora 是 OpenAI 于 2024 年 2 月发布的革命性文本到视频生成模型。它能够根据文本描述生成长达一分钟的高质量、高保真视频内容。

## 技术架构

Sora 采用了创新的技术架构：
- **扩散 Transformer**：结合扩散模型和 Transformer 架构
- **时空补丁**：将视频和图像表示为时空补丁集合
- **可变分辨率**：支持生成不同分辨率和宽高比的视频

## 能力特点

1. **物理世界模拟**：展示了对物理世界规律的理解
2. **时间一致性**：保持视频中物体和场景的连贯性
3. **复杂场景**：能够处理多角色、多动作的复杂场景
    `,
    author: {
      id: "u3",
      name: "科技编辑",
      avatar: "/tech-editor-avatar.jpg",
      bio: "专注于AI和科技报道",
      contributions: 189,
    },
    stats: { views: 28000, likes: 1567, comments: 289 },
    tags: ["视频生成", "AIGC", "扩散模型"],
    createdAt: "昨天",
    updatedAt: "2024-01-13",
    isVerified: true,
    references: [],
  },
  {
    id: "4",
    title: "神经形态计算",
    category: "芯片半导体",
    categorySlug: "semiconductor",
    summary: "神经形态计算是一种模仿人脑神经网络结构的计算范式，通过专门设计的神经形态芯片实现高效AI推理。",
    content: `
## 概述

神经形态计算（Neuromorphic Computing）是一种受人脑结构和功能启发的计算范式，旨在通过模仿生物神经网络的信息处理方式来实现更高效的计算。

## 核心原理

### 脉冲神经网络
- 使用脉冲信号而非连续值传递信息
- 基于事件驱动的计算方式
- 具有时序编码能力

### 存内计算
- 在存储单元内直接进行计算
- 消除了数据搬移的能耗
- 实现高度并行处理

## 代表性芯片

1. **Intel Loihi 2**：支持100万神经元
2. **IBM TrueNorth**：低功耗神经形态芯片
3. **BrainScaleS**：欧洲脑计划研发
    `,
    author: {
      id: "u4",
      name: "芯片工程师",
      avatar: "/chip-engineer-avatar.jpg",
      bio: "半导体行业从业15年",
      contributions: 112,
    },
    stats: { views: 8900, likes: 623, comments: 87 },
    tags: ["类脑计算", "AI芯片", "低功耗"],
    createdAt: "2天前",
    updatedAt: "2024-01-12",
    isVerified: true,
    references: [],
  },
  {
    id: "5",
    title: "合成生物学",
    category: "生物科技",
    categorySlug: "biotech",
    summary: "合成生物学是一门结合生物学和工程学的新兴学科，旨在设计和构建新的生物系统。",
    content: `
## 概述

合成生物学（Synthetic Biology）是21世纪新兴的交叉学科，结合了生物学、工程学、计算机科学等多个领域。其核心目标是设计和构建新的生物组件、系统和生物体。

## 关键技术

### 基因合成
- DNA 从头合成技术
- 基因组规模的 DNA 组装

### 基因编辑
- CRISPR-Cas9 系统
- 碱基编辑和先导编辑

### 代谢工程
- 代谢途径的重新设计
- 异源代谢途径的构建
    `,
    author: {
      id: "u5",
      name: "生物学博士",
      avatar: "/biologist-avatar.jpg",
      bio: "专注于合成生物学研究",
      contributions: 145,
    },
    stats: { views: 6700, likes: 445, comments: 62 },
    tags: ["基因编辑", "CRISPR", "生物工程"],
    createdAt: "3天前",
    updatedAt: "2024-01-11",
    isVerified: true,
    references: [],
  },
  {
    id: "6",
    title: "量子纠错",
    category: "量子计算",
    categorySlug: "quantum",
    summary: "量子纠错是量子计算中保护量子信息免受噪声和退相干影响的关键技术。",
    content: `## 概述\n\n量子纠错（Quantum Error Correction, QEC）是量子计算领域的核心技术之一，旨在保护脆弱的量子信息免受环境噪声和量子退相干的影响。`,
    author: {
      id: "u6",
      name: "量子物理博士",
      avatar: "/quantum-physicist-avatar.jpg",
      bio: "量子信息理论研究者",
      contributions: 234,
    },
    stats: { views: 5600, likes: 389, comments: 45 },
    tags: ["量子计算", "纠错码", "容错计算"],
    createdAt: "4天前",
    updatedAt: "2024-01-10",
    isVerified: true,
    references: [],
  },
  {
    id: "7",
    title: "可控核聚变",
    category: "新能源",
    categorySlug: "energy",
    summary: "可控核聚变是人类追求的终极能源解决方案，模仿太阳的能量产生机制。",
    content: `## 概述\n\n可控核聚变是指在人工控制条件下实现的核聚变反应，被誉为人类的"终极能源"。`,
    author: {
      id: "u7",
      name: "能源研究员",
      avatar: "/energy-researcher-avatar.jpg",
      bio: "清洁能源研究专家",
      contributions: 98,
    },
    stats: { views: 15200, likes: 1023, comments: 156 },
    tags: ["核聚变", "清洁能源", "ITER"],
    createdAt: "5天前",
    updatedAt: "2024-01-09",
    isVerified: true,
    references: [],
  },
  {
    id: "8",
    title: "脑机接口",
    category: "生物科技",
    categorySlug: "biotech",
    summary: "脑机接口是一种在大脑与外部设备之间建立直接通信通道的技术。",
    content: `## 概述\n\n脑机接口（Brain-Computer Interface, BCI）是一种可以在大脑与外部设备之间建立直接通信通道的技术系统。`,
    author: {
      id: "u8",
      name: "神经科学家",
      avatar: "/neuroscientist-avatar.jpg",
      bio: "神经工程学研究者",
      contributions: 167,
    },
    stats: { views: 21000, likes: 1456, comments: 234 },
    tags: ["神经科学", "Neuralink", "人机交互"],
    createdAt: "1周前",
    updatedAt: "2024-01-08",
    isVerified: true,
    references: [],
  },
]

export const categories = [
  {
    label: "人工智能",
    slug: "ai",
    description: "机器学习、深度学习、大语言模型等AI前沿技术",
    count: 1234,
    color: "bg-blue-500",
  },
  {
    label: "生物科技",
    slug: "biotech",
    description: "基因编辑、合成生物学、脑机接口等生命科学技术",
    count: 856,
    color: "bg-green-500",
  },
  {
    label: "量子计算",
    slug: "quantum",
    description: "量子比特、量子纠错、量子算法等量子技术",
    count: 423,
    color: "bg-purple-500",
  },
  {
    label: "航天科技",
    slug: "space",
    description: "火箭发射、卫星系统、深空探测等航天技术",
    count: 567,
    color: "bg-orange-500",
  },
  {
    label: "新能源",
    slug: "energy",
    description: "核聚变、氢能源、储能技术等清洁能源",
    count: 789,
    color: "bg-yellow-500",
  },
  {
    label: "芯片半导体",
    slug: "semiconductor",
    description: "先进制程、芯片设计、封装技术等",
    count: 645,
    color: "bg-red-500",
  },
  { label: "元宇宙", slug: "metaverse", description: "VR/AR、数字孪生、虚拟经济等", count: 334, color: "bg-pink-500" },
  { label: "区块链", slug: "blockchain", description: "加密货币、智能合约、Web3等", count: 521, color: "bg-cyan-500" },
  {
    label: "网络安全",
    slug: "security",
    description: "加密技术、隐私保护、安全防护等",
    count: 412,
    color: "bg-slate-500",
  },
  {
    label: "材料科学",
    slug: "materials",
    description: "超导材料、纳米材料、新型合金等",
    count: 298,
    color: "bg-teal-500",
  },
]

export const users = [
  {
    id: "u1",
    name: "AI研究员",
    avatar: "/ai-researcher-portrait.jpg",
    bio: "专注于大语言模型和AGI研究，OpenAI技术博客译者",
    contributions: 234,
    followers: 12500,
    following: 156,
    specialties: ["机器学习", "NLP", "AGI"],
    joinedAt: "2023-01-15",
    isVerified: true,
  },
  {
    id: "u2",
    name: "材料科学家",
    avatar: "/material-scientist-portrait.jpg",
    bio: "材料科学与物理学交叉研究，专注于超导材料",
    contributions: 156,
    followers: 8900,
    following: 89,
    specialties: ["超导", "纳米材料", "凝聚态物理"],
    joinedAt: "2023-03-20",
    isVerified: true,
  },
  {
    id: "u3",
    name: "科技编辑",
    avatar: "/tech-editor-portrait.jpg",
    bio: "专注于AI和科技报道，前科技媒体主编",
    contributions: 189,
    followers: 15600,
    following: 234,
    specialties: ["科技新闻", "产业分析", "深度报道"],
    joinedAt: "2022-11-08",
    isVerified: true,
  },
  {
    id: "u4",
    name: "量子物理博士",
    avatar: "/quantum-physicist-portrait.jpg",
    bio: "量子信息理论研究者，发表SCI论文50余篇",
    contributions: 234,
    followers: 9800,
    following: 67,
    specialties: ["量子计算", "量子通信", "量子密码"],
    joinedAt: "2023-02-14",
    isVerified: true,
  },
]

export const comments = [
  {
    id: "c1",
    termId: "1",
    author: { id: "u2", name: "材料科学家", avatar: "/diverse-user-avatars.png" },
    content: "GPT-5 如果真能实现这些能力，将会对科研工作产生巨大影响。期待能用它来辅助材料设计！",
    likes: 45,
    createdAt: "1小时前",
    replies: [
      {
        id: "r1",
        author: { id: "u1", name: "AI研究员", avatar: "/researcher-avatar.png" },
        content: "是的，AI for Science 正在成为一个重要的研究方向。",
        likes: 12,
        createdAt: "30分钟前",
      },
    ],
  },
  {
    id: "c2",
    termId: "1",
    author: { id: "u3", name: "科技编辑", avatar: "/editor-avatar.png" },
    content: "从技术演进的角度来看，GPT-5 的发布时间可能会比预期更晚，因为算力和安全性的挑战都很大。",
    likes: 32,
    createdAt: "2小时前",
    replies: [],
  },
]

export const notifications = [
  {
    id: "n1",
    type: "like",
    actor: { name: "量子物理博士", avatar: "/physicist-avatar.jpg" },
    target: "GPT-5",
    targetId: "1",
    createdAt: "5分钟前",
    isRead: false,
  },
  {
    id: "n2",
    type: "comment",
    actor: { name: "材料科学家", avatar: "/scientist-avatar.png" },
    target: "室温超导体 LK-99",
    targetId: "2",
    content: "这个词条写得很全面，学习了！",
    createdAt: "30分钟前",
    isRead: false,
  },
  {
    id: "n3",
    type: "follow",
    actor: { name: "科技爱好者", avatar: "/tech-fan-avatar.jpg" },
    createdAt: "1小时前",
    isRead: true,
  },
  {
    id: "n4",
    type: "mention",
    actor: { name: "AI研究员", avatar: "/ai-avatar.png" },
    target: "Sora 的技术架构分析",
    targetId: "3",
    createdAt: "2小时前",
    isRead: true,
  },
  {
    id: "n5",
    type: "system",
    content: "恭喜！你的词条「神经形态计算」已被收录为精选词条",
    createdAt: "昨天",
    isRead: true,
  },
]

// 论文模拟数据
export const mockPapers = [
  {
    id: "p1",
    title: "Attention Is All You Need",
    titleCn: "注意力机制就是你所需要的一切",
    authors: [
      { name: "Ashish Vaswani", affiliation: "Google Brain" },
      { name: "Noam Shazeer", affiliation: "Google Brain" },
      { name: "Niki Parmar", affiliation: "Google Research" },
      { name: "Jakob Uszkoreit", affiliation: "Google Research" },
      { name: "Llion Jones", affiliation: "Google Research" },
      { name: "Aidan N. Gomez", affiliation: "University of Toronto" },
      { name: "Łukasz Kaiser", affiliation: "Google Brain" },
      { name: "Illia Polosukhin", affiliation: "Google Research" },
    ],
    abstract:
      "The dominant sequence transduction models are based on complex recurrent or convolutional neural networks that include an encoder and a decoder. The best performing models also connect the encoder and decoder through an attention mechanism. We propose a new simple network architecture, the Transformer, based solely on attention mechanisms, dispensing with recurrence and convolutions entirely. Experiments on two machine translation tasks show these models to be superior in quality while being more parallelizable and requiring significantly less time to train.",
    abstractCn:
      "主流的序列转换模型基于复杂的循环或卷积神经网络，包含编码器和解码器。表现最好的模型还通过注意力机制连接编码器和解码器。我们提出了一种新的简单网络架构——Transformer，完全基于注意力机制，完全摒弃了循环和卷积。在两个机器翻译任务上的实验表明，这些模型在质量上更优越，同时更易于并行化，训练时间也大大减少。",
    category: "人工智能",
    categorySlug: "ai",
    journal: "NeurIPS 2017",
    publishDate: "2017-06-12",
    arxivId: "1706.03762",
    doi: "10.48550/arXiv.1706.03762",
    pdfUrl: "https://arxiv.org/pdf/1706.03762",
    tags: ["Transformer", "注意力机制", "深度学习", "NLP"],
    stats: { citations: 98000, views: 1250000, downloads: 450000, likes: 8956 },
    relatedTerms: ["1", "3"], // 关联的词条ID
    isHighlighted: true,
  },
  {
    id: "p2",
    title: "BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding",
    titleCn: "BERT：用于语言理解的深度双向Transformer预训练",
    authors: [
      { name: "Jacob Devlin", affiliation: "Google AI Language" },
      { name: "Ming-Wei Chang", affiliation: "Google AI Language" },
      { name: "Kenton Lee", affiliation: "Google AI Language" },
      { name: "Kristina Toutanova", affiliation: "Google AI Language" },
    ],
    abstract:
      "We introduce a new language representation model called BERT, which stands for Bidirectional Encoder Representations from Transformers. Unlike recent language representation models, BERT is designed to pre-train deep bidirectional representations from unlabeled text by jointly conditioning on both left and right context in all layers.",
    abstractCn:
      "我们介绍了一种新的语言表示模型BERT，即Transformers的双向编码器表示。与最近的语言表示模型不同，BERT旨在通过在所有层中同时对左右上下文进行条件化，从无标签文本中预训练深度双向表示。",
    category: "人工智能",
    categorySlug: "ai",
    journal: "NAACL 2019",
    publishDate: "2018-10-11",
    arxivId: "1810.04805",
    doi: "10.48550/arXiv.1810.04805",
    pdfUrl: "https://arxiv.org/pdf/1810.04805",
    tags: ["BERT", "预训练", "NLP", "语言模型"],
    stats: { citations: 85000, views: 980000, downloads: 380000, likes: 7234 },
    relatedTerms: ["1"],
    isHighlighted: true,
  },
  {
    id: "p3",
    title: "Room-temperature superconductivity in a carbonaceous sulfur hydride",
    titleCn: "含碳硫氢化物中的室温超导性",
    authors: [
      { name: "Elliot Snider", affiliation: "University of Rochester" },
      { name: "Nathan Dasenbrock-Gammon", affiliation: "University of Rochester" },
      { name: "Raymond McBride", affiliation: "University of Rochester" },
      { name: "Ranga P. Dias", affiliation: "University of Rochester" },
    ],
    abstract:
      "Superconductivity at room temperature has been a long-sought goal in condensed matter physics. We report superconductivity in a photochemically transformed carbonaceous sulfur hydride system at 287.7 ± 1.2 K (about 15 °C) at a pressure of 267 ± 10 gigapascals.",
    abstractCn:
      "室温超导性一直是凝聚态物理学的长期追求目标。我们报告了在267±10吉帕压力下，光化学转化的含碳硫氢化物系统中在287.7±1.2 K（约15°C）下的超导性。",
    category: "材料科学",
    categorySlug: "materials",
    journal: "Nature",
    publishDate: "2020-10-14",
    arxivId: null,
    doi: "10.1038/s41586-020-2801-z",
    pdfUrl: null,
    tags: ["超导", "高压物理", "材料科学"],
    stats: { citations: 1200, views: 520000, downloads: 85000, likes: 3456 },
    relatedTerms: ["2"],
    isHighlighted: false,
  },
  {
    id: "p4",
    title: "Sora: A Review on Background, Technology, Limitations, and Opportunities of Large Vision Models",
    titleCn: "Sora：大型视觉模型的背景、技术、局限性和机遇综述",
    authors: [
      { name: "Yixin Liu", affiliation: "Tsinghua University" },
      { name: "Kai Zhang", affiliation: "Tsinghua University" },
      { name: "Yuan Li", affiliation: "Peking University" },
    ],
    abstract:
      "Sora is a text-to-video generative AI model released by OpenAI in February 2024. The model is trained to generate videos of realistic or imaginative scenes from text instructions and shows potential as a world simulator. This paper presents a comprehensive review of background, technology, limitations, and opportunities for Sora.",
    abstractCn:
      "Sora是OpenAI于2024年2月发布的文本生成视频AI模型。该模型经过训练，可根据文本指令生成逼真或富有想象力的场景视频，并展示了作为世界模拟器的潜力。本文全面综述了Sora的背景、技术、局限性和机遇。",
    category: "人工智能",
    categorySlug: "ai",
    journal: "arXiv",
    publishDate: "2024-02-20",
    arxivId: "2402.17177",
    doi: "10.48550/arXiv.2402.17177",
    pdfUrl: "https://arxiv.org/pdf/2402.17177",
    tags: ["Sora", "视频生成", "AIGC", "多模态"],
    stats: { citations: 450, views: 180000, downloads: 45000, likes: 2890 },
    relatedTerms: ["3"],
    isHighlighted: true,
  },
  {
    id: "p5",
    title: "Neuromorphic computing with nanoscale spintronic oscillators",
    titleCn: "基于纳米自旋电子振荡器的神经形态计算",
    authors: [
      { name: "Jacob Torrejon", affiliation: "CNRS" },
      { name: "Mathieu Riou", affiliation: "CNRS" },
      { name: "Damien Querlioz", affiliation: "Université Paris-Saclay" },
    ],
    abstract:
      "Neuromorphic computing using non-volatile memories for artificial synapses and spintronic nano-oscillators for neurons is a promising approach for energy-efficient artificial intelligence. We demonstrate that a network of spintronic nano-oscillators can implement a hardware reservoir computer.",
    abstractCn:
      "使用非易失性存储器作为人工突触和自旋电子纳米振荡器作为神经元的神经形态计算，是实现节能人工智能的有前途的方法。我们证明了自旋电子纳米振荡器网络可以实现硬件储层计算机。",
    category: "芯片半导体",
    categorySlug: "semiconductor",
    journal: "Nature",
    publishDate: "2017-07-27",
    arxivId: null,
    doi: "10.1038/nature23011",
    pdfUrl: null,
    tags: ["神经形态", "自旋电子", "AI芯片", "类脑计算"],
    stats: { citations: 890, views: 125000, downloads: 32000, likes: 1567 },
    relatedTerms: ["4"],
    isHighlighted: false,
  },
  {
    id: "p6",
    title: "CRISPR-Cas9 gene editing in human cells",
    titleCn: "人类细胞中的CRISPR-Cas9基因编辑",
    authors: [
      { name: "Le Cong", affiliation: "MIT" },
      { name: "Feng Zhang", affiliation: "MIT" },
    ],
    abstract:
      "The CRISPR-Cas9 system provides a powerful tool for genome editing. Here we demonstrate that CRISPR-Cas9 can efficiently mediate targeted genome modifications in human cells.",
    abstractCn:
      "CRISPR-Cas9系统为基因组编辑提供了强大的工具。在这里，我们证明CRISPR-Cas9可以在人类细胞中有效地介导靶向基因组修饰。",
    category: "生物科技",
    categorySlug: "biotech",
    journal: "Science",
    publishDate: "2013-02-15",
    arxivId: null,
    doi: "10.1126/science.1231143",
    pdfUrl: null,
    tags: ["CRISPR", "基因编辑", "生物技术"],
    stats: { citations: 25000, views: 890000, downloads: 210000, likes: 5678 },
    relatedTerms: ["5"],
    isHighlighted: true,
  },
  {
    id: "p7",
    title: "Quantum supremacy using a programmable superconducting processor",
    titleCn: "使用可编程超导处理器实现量子霸权",
    authors: [
      { name: "Frank Arute", affiliation: "Google AI Quantum" },
      { name: "Kunal Arya", affiliation: "Google AI Quantum" },
      { name: "John M. Martinis", affiliation: "Google AI Quantum" },
    ],
    abstract:
      "The promise of quantum computers is that certain computational tasks might be executed exponentially faster on a quantum processor than on a classical processor. Here we report the use of a processor with programmable superconducting qubits to create quantum states on 53 qubits.",
    abstractCn:
      "量子计算机的承诺是某些计算任务在量子处理器上的执行速度可能比经典处理器快指数级。在这里，我们报告了使用具有可编程超导量子比特的处理器在53个量子比特上创建量子态。",
    category: "量子计算",
    categorySlug: "quantum",
    journal: "Nature",
    publishDate: "2019-10-23",
    arxivId: null,
    doi: "10.1038/s41586-019-1666-5",
    pdfUrl: null,
    tags: ["量子霸权", "超导量子比特", "量子计算"],
    stats: { citations: 4500, views: 650000, downloads: 120000, likes: 4123 },
    relatedTerms: ["6"],
    isHighlighted: true,
  },
  {
    id: "p8",
    title: "ITER: the way to fusion energy",
    titleCn: "ITER：通往聚变能源之路",
    authors: [{ name: "Bernard Bigot", affiliation: "ITER Organization" }],
    abstract:
      "ITER is an international nuclear fusion research and engineering megaproject aimed at proving the feasibility of fusion as a large-scale and carbon-free source of energy. This paper reviews the progress and challenges of the ITER project.",
    abstractCn:
      "ITER是一个国际核聚变研究和工程超大型项目，旨在证明聚变作为大规模无碳能源来源的可行性。本文回顾了ITER项目的进展和挑战。",
    category: "新能源",
    categorySlug: "energy",
    journal: "Nature Physics",
    publishDate: "2022-03-15",
    arxivId: null,
    doi: "10.1038/s41567-022-01234-8",
    pdfUrl: null,
    tags: ["核聚变", "ITER", "清洁能源", "等离子体物理"],
    stats: { citations: 320, views: 180000, downloads: 45000, likes: 2345 },
    relatedTerms: ["7"],
    isHighlighted: false,
  },
]

// 期刊/会议列表
export const journals = [
  { name: "Nature", count: 234, impact: 69.5 },
  { name: "Science", count: 189, impact: 63.7 },
  { name: "NeurIPS", count: 567, impact: null },
  { name: "ICML", count: 423, impact: null },
  { name: "CVPR", count: 389, impact: null },
  { name: "arXiv", count: 2345, impact: null },
  { name: "Cell", count: 156, impact: 66.8 },
  { name: "Nature Physics", count: 123, impact: 20.6 },
]

// 论文讨论/解读
export const paperDiscussions = [
  {
    id: "pd1",
    paperId: "p1",
    author: { id: "u1", name: "AI研究员", avatar: "/ai-researcher-avatar.jpg" },
    title: "Transformer架构的革命性意义",
    content:
      "这篇论文彻底改变了NLP乃至整个深度学习领域。Self-attention机制的提出使得模型能够并行处理序列，大大提高了训练效率...",
    likes: 567,
    comments: 89,
    createdAt: "2024-01-10",
    type: "interpretation", // interpretation: 解读, discussion: 讨论, question: 问题
  },
  {
    id: "pd2",
    paperId: "p1",
    author: { id: "u3", name: "科技编辑", avatar: "/tech-editor-avatar.jpg" },
    title: "从Transformer到GPT：技术演进路线",
    content: "Attention Is All You Need发表7年来，基于Transformer的模型经历了爆发式发展...",
    likes: 345,
    comments: 56,
    createdAt: "2024-01-08",
    type: "interpretation",
  },
]
