import { query, queryOne, execute } from "@/lib/db/connection"

export interface User {
  id: number
  email: string
  password_hash: string
  name: string
  avatar: string
  bio: string | null
  points: number
  level: number
  contributions: number
  followers_count: number
  following_count: number
  streak: number
  last_check_in: string | null
  is_verified: boolean
  wechat_qr_code: string | null
  alipay_qr_code: string | null
  role: 'user' | 'admin'
  joined_at: string
  created_at: string
  updated_at: string
}

export interface UserPublic {
  id: number
  name: string
  avatar: string
  bio: string | null
  contributions: number
  followers_count: number
  following_count: number
  points: number
  level: number
  is_verified: boolean
  wechat_qr_code: string | null
  alipay_qr_code: string | null
  joined_at: string
}

export interface UserBadge {
  id: number
  user_id: number
  badge_id: string
  badge_name: string
  icon: string
  description: string | null
  earned_at: string
}

export interface UserSpecialty {
  user_id: number
  specialty: string
}

/**
 * 根据邮箱查找用户
 */
export async function findUserByEmail(email: string): Promise<User | null> {
  return queryOne<User>(
    "SELECT * FROM users WHERE email = ?",
    [email]
  )
}

/**
 * 根据ID查找用户
 */
export async function findUserById(id: number): Promise<User | null> {
  return queryOne<User>(
    "SELECT * FROM users WHERE id = ?",
    [id]
  )
}

/**
 * 创建用户
 */
export async function createUser(
  email: string,
  passwordHash: string,
  name: string
): Promise<number> {
  const result = await execute(
    "INSERT INTO users (email, password_hash, name) VALUES (?, ?, ?)",
    [email, passwordHash, name]
  )
  return result.insertId
}

/**
 * 更新用户信息
 */
export async function updateUser(
  id: number,
  data: Partial<Pick<User, "name" | "avatar" | "bio" | "points" | "level" | "streak" | "last_check_in" | "is_verified" | "contributions" | "wechat_qr_code" | "alipay_qr_code" | "role" | "followers_count" | "following_count">>
): Promise<void> {
  const fields: string[] = []
  const values: any[] = []

  Object.entries(data).forEach(([key, value]) => {
    if (value !== undefined) {
      fields.push(`${key} = ?`)
      values.push(value)
    }
  })

  if (fields.length === 0) return

  values.push(id)
  await execute(
    `UPDATE users SET ${fields.join(", ")} WHERE id = ?`,
    values
  )
}

/**
 * 获取用户公开信息
 */
export async function getUserPublic(id: number): Promise<UserPublic | null> {
  return queryOne<UserPublic>(
    `SELECT id, name, avatar, bio, contributions, followers_count, 
     following_count, points, level, is_verified, wechat_qr_code, alipay_qr_code, joined_at 
     FROM users WHERE id = ?`,
    [id]
  )
}

/**
 * 获取用户徽章
 */
export async function getUserBadges(userId: number): Promise<UserBadge[]> {
  return query<UserBadge>(
    "SELECT * FROM user_badges WHERE user_id = ? ORDER BY earned_at DESC",
    [userId]
  )
}

/**
 * 添加用户徽章
 */
export async function addUserBadge(
  userId: number,
  badgeId: string,
  badgeName: string,
  icon: string,
  description: string | null
): Promise<void> {
  await execute(
    `INSERT INTO user_badges (user_id, badge_id, badge_name, icon, description) 
     VALUES (?, ?, ?, ?, ?)`,
    [userId, badgeId, badgeName, icon, description]
  )
}

/**
 * 获取用户专业领域
 */
export async function getUserSpecialties(userId: number): Promise<string[]> {
  const specialties = await query<UserSpecialty>(
    "SELECT specialty FROM user_specialties WHERE user_id = ?",
    [userId]
  )
  return specialties.map((s) => s.specialty)
}

/**
 * 设置用户专业领域
 */
export async function setUserSpecialties(
  userId: number,
  specialties: string[]
): Promise<void> {
  // 先删除旧的
  await execute("DELETE FROM user_specialties WHERE user_id = ?", [userId])
  // 插入新的
  if (specialties.length > 0) {
    const values = specialties.map(() => "(?, ?)").join(", ")
    const params = specialties.flatMap((s) => [userId, s])
    await execute(
      `INSERT INTO user_specialties (user_id, specialty) VALUES ${values}`,
      params
    )
  }
}

/**
 * 检查是否关注
 */
export async function isFollowing(
  followerId: number,
  followingId: number
): Promise<boolean> {
  const result = await queryOne<{ count: number }>(
    "SELECT COUNT(*) as count FROM follows WHERE follower_id = ? AND following_id = ?",
    [followerId, followingId]
  )
  return (result?.count || 0) > 0
}

/**
 * 关注用户
 */
export async function followUser(
  followerId: number,
  followingId: number
): Promise<void> {
  if (followerId === followingId) {
    throw new Error("Cannot follow yourself")
  }

  await execute(
    "INSERT INTO follows (follower_id, following_id) VALUES (?, ?) ON DUPLICATE KEY UPDATE follower_id = follower_id",
    [followerId, followingId]
  )

  // 更新关注数
  await execute(
    "UPDATE users SET following_count = following_count + 1 WHERE id = ?",
    [followerId]
  )
  await execute(
    "UPDATE users SET followers_count = followers_count + 1 WHERE id = ?",
    [followingId]
  )
}

/**
 * 取消关注
 */
export async function unfollowUser(
  followerId: number,
  followingId: number
): Promise<void> {
  const result = await execute(
    "DELETE FROM follows WHERE follower_id = ? AND following_id = ?",
    [followerId, followingId]
  )

  if (result.affectedRows > 0) {
    // 更新关注数
    await execute(
      "UPDATE users SET following_count = following_count - 1 WHERE id = ?",
      [followerId]
    )
    await execute(
      "UPDATE users SET followers_count = followers_count - 1 WHERE id = ?",
      [followingId]
    )
  }
}
