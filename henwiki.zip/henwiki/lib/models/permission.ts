import { query, queryOne, execute } from "@/lib/db/connection"

export interface Permission {
  id: number
  code: string
  name: string
  description: string | null
  module: string
  resource: string
  action: string
  created_at: string
  updated_at: string
}

/**
 * 根据权限代码查找权限
 */
export async function findPermissionByCode(code: string): Promise<Permission | null> {
  return queryOne<Permission>(
    "SELECT * FROM permissions WHERE code = ?",
    [code]
  )
}

/**
 * 获取所有权限
 */
export async function getAllPermissions(): Promise<Permission[]> {
  return query<Permission>(
    "SELECT * FROM permissions ORDER BY module, resource, action"
  )
}

/**
 * 根据模块获取权限
 */
export async function getPermissionsByModule(module: string): Promise<Permission[]> {
  return query<Permission>(
    "SELECT * FROM permissions WHERE module = ? ORDER BY resource, action",
    [module]
  )
}

/**
 * 检查用户是否拥有指定权限
 */
export async function userHasPermission(userId: number, permissionCode: string): Promise<boolean> {
  const result = await queryOne<{ count: number }>(
    `SELECT COUNT(*) as count
     FROM user_roles ur
     INNER JOIN role_permissions rp ON ur.role_id = rp.role_id
     INNER JOIN permissions p ON rp.permission_id = p.id
     WHERE ur.user_id = ? AND p.code = ?`,
    [userId, permissionCode]
  )
  return (result?.count || 0) > 0
}

/**
 * 获取用户的所有权限
 */
export async function getUserPermissions(userId: number): Promise<Permission[]> {
  return query<Permission>(
    `SELECT DISTINCT p.*
     FROM permissions p
     INNER JOIN role_permissions rp ON p.id = rp.permission_id
     INNER JOIN user_roles ur ON rp.role_id = ur.role_id
     WHERE ur.user_id = ?
     ORDER BY p.module, p.resource, p.action`,
    [userId]
  )
}

/**
 * 获取用户的权限代码列表（用于快速检查）
 */
export async function getUserPermissionCodes(userId: number): Promise<string[]> {
  const permissions = await getUserPermissions(userId)
  return permissions.map(p => p.code)
}

/**
 * 检查用户是否拥有任一权限
 */
export async function userHasAnyPermission(userId: number, permissionCodes: string[]): Promise<boolean> {
  if (permissionCodes.length === 0) return false
  
  const placeholders = permissionCodes.map(() => "?").join(",")
  const result = await queryOne<{ count: number }>(
    `SELECT COUNT(*) as count
     FROM user_roles ur
     INNER JOIN role_permissions rp ON ur.role_id = rp.role_id
     INNER JOIN permissions p ON rp.permission_id = p.id
     WHERE ur.user_id = ? AND p.code IN (${placeholders})`,
    [userId, ...permissionCodes]
  )
  return (result?.count || 0) > 0
}

/**
 * 检查用户是否拥有所有权限
 */
export async function userHasAllPermissions(userId: number, permissionCodes: string[]): Promise<boolean> {
  if (permissionCodes.length === 0) return true
  
  const placeholders = permissionCodes.map(() => "?").join(",")
  const result = await queryOne<{ count: number }>(
    `SELECT COUNT(DISTINCT p.code) as count
     FROM user_roles ur
     INNER JOIN role_permissions rp ON ur.role_id = rp.role_id
     INNER JOIN permissions p ON rp.permission_id = p.id
     WHERE ur.user_id = ? AND p.code IN (${placeholders})`,
    [userId, ...permissionCodes]
  )
  return (result?.count || 0) === permissionCodes.length
}
