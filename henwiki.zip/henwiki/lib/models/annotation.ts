import { query, queryOne, execute, transaction } from "@/lib/db/connection"

export interface Annotation {
  id: number
  user_id: number
  term_id: number
  target_type: "term" | "paper"
  selected_text: string
  start_offset: number
  end_offset: number
  color: string
  note: string | null
  tags: string[]
  created_at: string
  updated_at: string
}

/**
 * 获取用户的标记列表
 */
export async function getAnnotations(params: {
  userId: number
  termId?: number
  targetType?: "term" | "paper"
}): Promise<Annotation[]> {
  const { userId, termId, targetType } = params

  const conditions: string[] = ["user_id = ?"]
  const values: any[] = [userId]

  if (termId) {
    conditions.push("term_id = ?")
    values.push(termId)
  }

  if (targetType) {
    conditions.push("target_type = ?")
    values.push(targetType)
  }

  const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(" AND ")}` : ""

  const annotations = await query<any>(
    `SELECT 
      id,
      user_id,
      term_id,
      target_type,
      selected_text,
      start_offset,
      end_offset,
      color,
      note,
      tags,
      created_at,
      updated_at
    FROM annotations
    ${whereClause}
    ORDER BY created_at DESC`,
    values
  )

  return annotations.map((a: any) => ({
    id: a.id,
    user_id: a.user_id,
    term_id: a.term_id,
    target_type: a.target_type,
    selected_text: a.selected_text,
    start_offset: a.start_offset,
    end_offset: a.end_offset,
    color: a.color,
    note: a.note,
    tags: a.tags ? (typeof a.tags === "string" ? JSON.parse(a.tags) : a.tags) : [],
    created_at: a.created_at,
    updated_at: a.updated_at,
  }))
}

/**
 * 根据ID获取标记
 */
export async function getAnnotationById(id: number, userId: number): Promise<Annotation | null> {
  const annotation = await queryOne<any>(
    `SELECT 
      id,
      user_id,
      term_id,
      target_type,
      selected_text,
      start_offset,
      end_offset,
      color,
      note,
      tags,
      created_at,
      updated_at
    FROM annotations
    WHERE id = ? AND user_id = ?`,
    [id, userId]
  )

  if (!annotation) return null

  return {
    id: annotation.id,
    user_id: annotation.user_id,
    term_id: annotation.term_id,
    target_type: annotation.target_type,
    selected_text: annotation.selected_text,
    start_offset: annotation.start_offset,
    end_offset: annotation.end_offset,
    color: annotation.color,
    note: annotation.note,
    tags: annotation.tags ? (typeof annotation.tags === "string" ? JSON.parse(annotation.tags) : annotation.tags) : [],
    created_at: annotation.created_at,
    updated_at: annotation.updated_at,
  }
}

/**
 * 创建标记
 */
export async function createAnnotation(data: {
  userId: number
  termId: number
  targetType: "term" | "paper"
  selectedText: string
  startOffset: number
  endOffset: number
  color?: string
  note?: string
  tags?: string[]
}): Promise<number> {
  const {
    userId,
    termId,
    targetType,
    selectedText,
    startOffset,
    endOffset,
    color = "yellow",
    note = null,
    tags = [],
  } = data

  const result = await execute(
    `INSERT INTO annotations (
      user_id,
      term_id,
      target_type,
      selected_text,
      start_offset,
      end_offset,
      color,
      note,
      tags
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [userId, termId, targetType, selectedText, startOffset, endOffset, color, note, JSON.stringify(tags)]
  )

  return result.insertId
}

/**
 * 更新标记
 */
export async function updateAnnotation(
  id: number,
  userId: number,
  data: {
    color?: string
    note?: string
    tags?: string[]
  }
): Promise<void> {
  const { color, note, tags } = data

  const fields: string[] = []
  const values: any[] = []

  if (color !== undefined) {
    fields.push("color = ?")
    values.push(color)
  }

  if (note !== undefined) {
    fields.push("note = ?")
    values.push(note)
  }

  if (tags !== undefined) {
    fields.push("tags = ?")
    values.push(JSON.stringify(tags))
  }

  if (fields.length === 0) {
    return
  }

  values.push(id, userId)

  await execute(
    `UPDATE annotations 
     SET ${fields.join(", ")} 
     WHERE id = ? AND user_id = ?`,
    values
  )
}

/**
 * 删除标记
 */
export async function deleteAnnotation(id: number, userId: number): Promise<void> {
  await execute("DELETE FROM annotations WHERE id = ? AND user_id = ?", [id, userId])
}
