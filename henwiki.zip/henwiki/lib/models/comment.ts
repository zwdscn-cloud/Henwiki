import { query, queryOne, execute, transaction } from "@/lib/db/connection"

export interface Comment {
  id: number
  term_id: number
  author_id: number
  content: string
  parent_id: number | null
  likes_count: number
  created_at: string
  updated_at: string
}

export interface CommentWithAuthor extends Comment {
  author: {
    id: number
    name: string
    avatar: string
  }
  replies?: CommentWithAuthor[]
}

/**
 * 获取用户的评论列表
 */
export async function getCommentsByUserId(userId: number): Promise<CommentWithAuthor[]> {
  const comments = await query<any>(
    `SELECT 
      c.*,
      u.id as author_id,
      u.name as author_name,
      u.avatar as author_avatar
    FROM comments c
    INNER JOIN users u ON c.author_id = u.id
    WHERE c.author_id = ?
    ORDER BY c.created_at DESC
    LIMIT 50`,
    [userId]
  )

  return comments.map((c: any) => ({
    id: c.id,
    term_id: c.term_id,
    author_id: c.author_id,
    content: c.content,
    parent_id: c.parent_id,
    likes_count: c.likes_count,
    created_at: c.created_at,
    updated_at: c.updated_at,
    author: {
      id: c.author_id,
      name: c.author_name,
      avatar: c.author_avatar || "/placeholder-user.jpg",
    },
  }))
}

/**
 * 获取词条的评论列表（树形结构）
 */
export async function getCommentsByTermId(termId: number): Promise<CommentWithAuthor[]> {
  const comments = await query<any>(
    `SELECT 
      c.*,
      u.id as author_id,
      u.name as author_name,
      u.avatar as author_avatar
    FROM comments c
    INNER JOIN users u ON c.author_id = u.id
    WHERE c.term_id = ?
    ORDER BY c.created_at ASC`,
    [termId]
  )

  // 构建树形结构
  const commentMap = new Map<number, CommentWithAuthor>()
  const rootComments: CommentWithAuthor[] = []

  comments.forEach((c: any) => {
    const comment: CommentWithAuthor = {
      id: c.id,
      term_id: c.term_id,
      author_id: c.author_id,
      content: c.content,
      parent_id: c.parent_id,
      likes_count: c.likes_count,
      created_at: c.created_at,
      updated_at: c.updated_at,
      author: {
        id: c.author_id,
        name: c.author_name,
        avatar: c.author_avatar,
      },
      replies: [],
    }

    commentMap.set(comment.id, comment)

    if (comment.parent_id) {
      const parent = commentMap.get(comment.parent_id)
      if (parent) {
        if (!parent.replies) {
          parent.replies = []
        }
        parent.replies.push(comment)
      }
    } else {
      rootComments.push(comment)
    }
  })

  return rootComments
}

/**
 * 创建评论
 */
export async function createComment(
  data: {
    termId: number
    authorId: number
    content: string
    parentId?: number
  }
): Promise<number> {
  return transaction(async (conn) => {
    const [result] = await conn.execute(
      `INSERT INTO comments (term_id, author_id, content, parent_id) 
       VALUES (?, ?, ?, ?)`,
      [data.termId, data.authorId, data.content, data.parentId || null]
    )

    const commentId = (result as any).insertId

    // 更新词条评论数
    await conn.execute(
      "UPDATE terms SET comments_count = comments_count + 1 WHERE id = ?",
      [data.termId]
    )

    return commentId
  })
}

/**
 * 删除评论
 */
export async function deleteComment(commentId: number, termId: number): Promise<void> {
  await transaction(async (conn) => {
    // 检查是否有子评论
    const [children] = await conn.execute(
      "SELECT id FROM comments WHERE parent_id = ?",
      [commentId]
    )

    if ((children as any[]).length > 0) {
      // 如果有子评论，只标记为已删除（软删除）或清空内容
      await conn.execute(
        "UPDATE comments SET content = '[已删除]' WHERE id = ?",
        [commentId]
      )
    } else {
      // 如果没有子评论，直接删除
      await conn.execute("DELETE FROM comments WHERE id = ?", [commentId])
      await conn.execute(
        "UPDATE terms SET comments_count = comments_count - 1 WHERE id = ?",
        [termId]
      )
    }
  })
}

/**
 * 切换评论点赞状态
 */
export async function toggleLike(
  commentId: number,
  userId: number
): Promise<{ liked: boolean; likesCount: number }> {
  return transaction(async (conn) => {
    const [existing] = await conn.execute(
      "SELECT id FROM likes WHERE user_id = ? AND target_type = 'comment' AND target_id = ?",
      [userId, commentId]
    )

    const rows = existing as any[]
    const isLiked = rows.length > 0

    if (isLiked) {
      await conn.execute(
        "DELETE FROM likes WHERE user_id = ? AND target_type = 'comment' AND target_id = ?",
        [userId, commentId]
      )
      await conn.execute(
        "UPDATE comments SET likes_count = likes_count - 1 WHERE id = ?",
        [commentId]
      )
    } else {
      await conn.execute(
        "INSERT INTO likes (user_id, target_type, target_id) VALUES (?, 'comment', ?)",
        [userId, commentId]
      )
      await conn.execute(
        "UPDATE comments SET likes_count = likes_count + 1 WHERE id = ?",
        [commentId]
      )
    }

    const comment = await queryOne<{ likes_count: number }>(
      "SELECT likes_count FROM comments WHERE id = ?",
      [commentId]
    )

    return {
      liked: !isLiked,
      likesCount: comment?.likes_count || 0,
    }
  })
}
