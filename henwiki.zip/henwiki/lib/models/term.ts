import { query, queryOne, execute, transaction } from "@/lib/db/connection"

export interface Term {
  id: number
  title: string
  category_id: number
  summary: string | null
  content: string | null
  author_id: number
  views: number
  likes_count: number
  dislikes_count: number
  comments_count: number
  is_verified: boolean
  status: "draft" | "pending" | "published" | "rejected"
  created_at: string
  updated_at: string
}

export interface TermWithRelations extends Term {
  category: {
    id: number
    slug: string
    label: string
  }
  author: {
    id: number
    name: string
    avatar: string
  }
  tags: string[]
}

/**
 * 获取词条列表
 */
export async function getTerms(params: {
  categoryId?: number
  status?: string
  page?: number
  pageSize?: number
  orderBy?: "created_at" | "views" | "likes_count" | "recommended" | "trending"
  userId?: number | null
  authorId?: number
  tag?: string
}): Promise<TermWithRelations[]> {
  const {
    categoryId,
    status,
    page = 1,
    pageSize = 20,
    orderBy = "created_at",
    userId = null,
    authorId,
    tag,
  } = params
  
  // 如果没有指定 status，默认只返回已发布的词条（除非是作者查看自己的词条）
  const finalStatus = status !== undefined ? status : (authorId ? undefined : "published")

  // 处理推荐和热门排序
  if (orderBy === "recommended" || orderBy === "trending") {
    const { getPersonalizedRecommendations, getGeneralRecommendations, getTrendingTerms } = await import("@/lib/utils/recommendation")
    
    let termIds: number[]
    if (orderBy === "recommended") {
      termIds = await getPersonalizedRecommendations(userId, pageSize * page, categoryId)
    } else {
      termIds = await getTrendingTerms(pageSize * page, categoryId)
    }

    if (termIds.length === 0) {
      return []
    }

    // 根据ID列表获取词条详情
    const offset = (page - 1) * pageSize
    const paginatedIds = termIds.slice(offset, offset + pageSize)
    
    if (paginatedIds.length === 0) {
      return []
    }

    const placeholders = paginatedIds.map(() => "?").join(",")
    const sql = `
      SELECT 
        t.id,
        t.title,
        t.category_id,
        t.summary,
        t.content,
        t.author_id,
        t.views,
        t.likes_count,
        t.comments_count,
        t.is_verified,
        t.status,
        t.created_at,
        t.updated_at,
        c.id as cat_id,
        c.slug as category_slug,
        c.label as category_label,
        u.id as user_id,
        u.name as author_name,
        u.avatar as author_avatar
      FROM terms t
      INNER JOIN categories c ON t.category_id = c.id
      INNER JOIN users u ON t.author_id = u.id
      WHERE t.id IN (${placeholders})${finalStatus !== undefined ? " AND t.status = ?" : ""}
      ORDER BY FIELD(t.id, ${placeholders})
    `

    const terms = await query<any>(sql, finalStatus !== undefined ? [...paginatedIds, finalStatus, ...paginatedIds] : [...paginatedIds, ...paginatedIds])
    
    // 获取标签
    const termIdsForTags = terms.map((t: any) => t.id)
    const tagsMap = new Map<number, string[]>()

    if (termIdsForTags.length > 0) {
      const tagPlaceholders = termIdsForTags.map(() => "?").join(",")
      const tags = await query<{ term_id: number; tag_name: string }>(
        `SELECT term_id, tag_name FROM term_tags WHERE term_id IN (${tagPlaceholders})`,
        termIdsForTags
      )

      tags.forEach((tag) => {
        if (!tagsMap.has(tag.term_id)) {
          tagsMap.set(tag.term_id, [])
        }
        tagsMap.get(tag.term_id)!.push(tag.tag_name)
      })
    }

    return terms.map((term: any) => ({
      id: term.id,
      title: term.title,
      category_id: term.category_id,
      summary: term.summary,
      content: term.content,
      author_id: term.author_id,
      views: term.views,
      likes_count: term.likes_count,
      comments_count: term.comments_count,
      is_verified: term.is_verified,
      status: term.status,
      created_at: term.created_at,
      updated_at: term.updated_at,
      category: {
        id: term.cat_id || term.category_id,
        slug: term.category_slug,
        label: term.category_label,
      },
      author: {
        id: term.user_id || term.author_id,
        name: term.author_name,
        avatar: term.author_avatar || "/placeholder-user.jpg",
      },
      tags: tagsMap.get(term.id) || [],
    }))
  }

  // 标准排序逻辑
  const offset = (page - 1) * pageSize
  const conditions: string[] = []
  const values: any[] = []
  
  // 只有当 finalStatus 不为 undefined 时才添加状态筛选
  if (finalStatus !== undefined) {
    conditions.push("t.status = ?")
    values.push(finalStatus)
  }

  if (categoryId) {
    conditions.push("t.category_id = ?")
    values.push(categoryId)
  }

  if (authorId) {
    conditions.push("t.author_id = ?")
    values.push(authorId)
  }

  // 处理标签筛选
  let tagJoin = ""
  if (tag) {
    tagJoin = "INNER JOIN term_tags tt ON t.id = tt.term_id"
    conditions.push("tt.tag_name = ?")
    values.push(tag)
  }

  // 验证 orderBy 字段，防止 SQL 注入
  const allowedOrderBy = ["created_at", "views", "likes_count"]
  const safeOrderBy = allowedOrderBy.includes(orderBy) ? orderBy : "created_at"

  const sql = `
    SELECT 
      t.id,
      t.title,
      t.category_id,
      t.summary,
      t.content,
      t.author_id,
      t.views,
      t.likes_count,
      t.comments_count,
      t.is_verified,
      t.status,
      t.created_at,
      t.updated_at,
      c.id as cat_id,
      c.slug as category_slug,
      c.label as category_label,
      u.id as user_id,
      u.name as author_name,
      u.avatar as author_avatar
    FROM terms t
    INNER JOIN categories c ON t.category_id = c.id
    INNER JOIN users u ON t.author_id = u.id
    ${tagJoin}
    WHERE ${conditions.join(" AND ")}
    ORDER BY t.${safeOrderBy} DESC
    LIMIT ? OFFSET ?
  `

  values.push(pageSize, offset)
  const terms = await query<any>(sql, values)

  // 获取每个词条的标签
  const termIds = terms.map((t: any) => t.id)
  const tagsMap = new Map<number, string[]>()

  if (termIds.length > 0) {
    const placeholders = termIds.map(() => "?").join(",")
    const tags = await query<{ term_id: number; tag_name: string }>(
      `SELECT term_id, tag_name FROM term_tags WHERE term_id IN (${placeholders})`,
      termIds
    )

    tags.forEach((tag) => {
      if (!tagsMap.has(tag.term_id)) {
        tagsMap.set(tag.term_id, [])
      }
      tagsMap.get(tag.term_id)!.push(tag.tag_name)
    })
  }

  return terms.map((term: any) => ({
    id: term.id,
    title: term.title,
    category_id: term.category_id,
    summary: term.summary,
    content: term.content,
    author_id: term.author_id,
    views: term.views,
    likes_count: term.likes_count,
    comments_count: term.comments_count,
    is_verified: term.is_verified,
    status: term.status,
    created_at: term.created_at,
    updated_at: term.updated_at,
    category: {
      id: term.cat_id || term.category_id,
      slug: term.category_slug,
      label: term.category_label,
    },
    author: {
      id: term.user_id || term.author_id,
      name: term.author_name,
      avatar: term.author_avatar || "/placeholder-user.jpg",
    },
    tags: tagsMap.get(term.id) || [],
  }))
}

/**
 * 根据ID获取词条详情
 */
export async function getTermById(id: number): Promise<TermWithRelations | null> {
  const term = await queryOne<any>(
    `SELECT 
      t.id,
      t.title,
      t.category_id,
      t.summary,
      t.content,
      t.author_id,
      t.views,
      t.likes_count,
      t.dislikes_count,
      t.comments_count,
      t.is_verified,
      t.status,
      t.created_at,
      t.updated_at,
      c.id as cat_id,
      c.slug as category_slug,
      c.label as category_label,
      u.id as user_id,
      u.name as author_name,
      u.avatar as author_avatar
    FROM terms t
    INNER JOIN categories c ON t.category_id = c.id
    INNER JOIN users u ON t.author_id = u.id
    WHERE t.id = ?`,
    [id]
  )

  if (!term) return null

  const tags = await query<{ tag_name: string }>(
    "SELECT tag_name FROM term_tags WHERE term_id = ?",
    [id]
  )

  return {
    id: term.id,
    title: term.title,
    category_id: term.category_id,
    summary: term.summary,
    content: term.content,
    author_id: term.author_id,
    views: term.views,
    likes_count: term.likes_count,
    dislikes_count: term.dislikes_count || 0,
    comments_count: term.comments_count,
    is_verified: term.is_verified,
    status: term.status,
    created_at: term.created_at,
    updated_at: term.updated_at,
    category: {
      id: term.cat_id || term.category_id,
      slug: term.category_slug,
      label: term.category_label,
    },
    author: {
      id: term.user_id || term.author_id,
      name: term.author_name,
      avatar: term.author_avatar || "/placeholder-user.jpg",
    },
    tags: tags.map((t) => t.tag_name),
  }
}

/**
 * 创建词条
 */
export async function createTerm(
  data: {
    title: string
    categoryId: number
    summary: string
    content: string
    authorId: number
    tags?: string[]
  }
): Promise<number> {
  return transaction(async (conn) => {
    const [result] = await conn.execute(
      `INSERT INTO terms (title, category_id, summary, content, author_id, status) 
       VALUES (?, ?, ?, ?, ?, 'pending')`,
      [data.title, data.categoryId, data.summary, data.content, data.authorId]
    )

    const termId = (result as any).insertId

    // 插入标签
    if (data.tags && data.tags.length > 0) {
      const tagValues = data.tags.map(() => "(?, ?)").join(", ")
      const tagParams = data.tags.flatMap((tag) => [termId, tag])
      await conn.execute(
        `INSERT INTO term_tags (term_id, tag_name) VALUES ${tagValues}`,
        tagParams
      )
    }

    // 更新用户贡献数
    await conn.execute(
      "UPDATE users SET contributions = contributions + 1 WHERE id = ?",
      [data.authorId]
    )

    return termId
  })
}

/**
 * 更新词条
 */
export async function updateTerm(
  id: number,
  data: {
    title?: string
    categoryId?: number
    summary?: string
    content?: string
    tags?: string[]
    status?: string
  }
): Promise<void> {
  await transaction(async (conn) => {
    const fields: string[] = []
    const values: any[] = []

    if (data.title !== undefined) {
      fields.push("title = ?")
      values.push(data.title)
    }
    if (data.categoryId !== undefined) {
      fields.push("category_id = ?")
      values.push(data.categoryId)
    }
    if (data.summary !== undefined) {
      fields.push("summary = ?")
      values.push(data.summary)
    }
    if (data.content !== undefined) {
      fields.push("content = ?")
      values.push(data.content)
    }
    if (data.status !== undefined) {
      fields.push("status = ?")
      values.push(data.status)
    }

    if (fields.length > 0) {
      values.push(id)
      await conn.execute(
        `UPDATE terms SET ${fields.join(", ")} WHERE id = ?`,
        values
      )
    }

    // 更新标签
    if (data.tags !== undefined) {
      await conn.execute("DELETE FROM term_tags WHERE term_id = ?", [id])
      if (data.tags.length > 0) {
        const tagValues = data.tags.map(() => "(?, ?)").join(", ")
        const tagParams = data.tags.flatMap((tag) => [id, tag])
        await conn.execute(
          `INSERT INTO term_tags (term_id, tag_name) VALUES ${tagValues}`,
          tagParams
        )
      }
    }
  })
}

/**
 * 删除词条
 */
export async function deleteTerm(id: number): Promise<void> {
  await execute("DELETE FROM terms WHERE id = ?", [id])
}

/**
 * 增加浏览量
 */
export async function incrementViews(id: number): Promise<void> {
  await execute("UPDATE terms SET views = views + 1 WHERE id = ?", [id])
}

/**
 * 切换点赞状态
 */
export async function toggleLike(
  termId: number,
  userId: number
): Promise<{ liked: boolean; likesCount: number }> {
  return transaction(async (conn) => {
    // 检查是否已点赞
    const [existing] = await conn.execute(
      "SELECT id FROM likes WHERE user_id = ? AND target_type = 'term' AND target_id = ?",
      [userId, termId]
    )

    const rows = existing as any[]
    const isLiked = rows.length > 0

    if (isLiked) {
      // 取消点赞
      await conn.execute(
        "DELETE FROM likes WHERE user_id = ? AND target_type = 'term' AND target_id = ?",
        [userId, termId]
      )
      await conn.execute(
        "UPDATE terms SET likes_count = likes_count - 1 WHERE id = ?",
        [termId]
      )
    } else {
      // 添加点赞
      await conn.execute(
        "INSERT INTO likes (user_id, target_type, target_id) VALUES (?, 'term', ?)",
        [userId, termId]
      )
      await conn.execute(
        "UPDATE terms SET likes_count = likes_count + 1 WHERE id = ?",
        [termId]
      )
    }

    // 获取更新后的点赞数
    const term = await queryOne<{ likes_count: number }>(
      "SELECT likes_count FROM terms WHERE id = ?",
      [termId]
    )

    return {
      liked: !isLiked,
      likesCount: term?.likes_count || 0,
    }
  })
}

/**
 * 检查用户是否已点赞
 */
export async function isLiked(termId: number, userId: number): Promise<boolean> {
  const result = await queryOne<{ count: number }>(
    "SELECT COUNT(*) as count FROM likes WHERE user_id = ? AND target_type = 'term' AND target_id = ?",
    [userId, termId]
  )
  return (result?.count || 0) > 0
}

/**
 * 切换踩状态
 */
export async function toggleDislike(
  termId: number,
  userId: number
): Promise<{ disliked: boolean }> {
  return transaction(async (conn) => {
    // 检查是否已踩
    const [existing] = await conn.execute(
      "SELECT id FROM dislikes WHERE user_id = ? AND target_type = 'term' AND target_id = ?",
      [userId, termId]
    )

    const rows = existing as any[]
    const isDisliked = rows.length > 0

    if (isDisliked) {
      // 取消踩
      await conn.execute(
        "DELETE FROM dislikes WHERE user_id = ? AND target_type = 'term' AND target_id = ?",
        [userId, termId]
      )
      await conn.execute(
        "UPDATE terms SET dislikes_count = GREATEST(dislikes_count - 1, 0) WHERE id = ?",
        [termId]
      )
    } else {
      // 添加踩
      await conn.execute(
        "INSERT INTO dislikes (user_id, target_type, target_id) VALUES (?, 'term', ?)",
        [userId, termId]
      )
      await conn.execute(
        "UPDATE terms SET dislikes_count = dislikes_count + 1 WHERE id = ?",
        [termId]
      )
    }

    return {
      disliked: !isDisliked,
    }
  })
}

/**
 * 检查用户是否已踩
 */
export async function isDisliked(termId: number, userId: number): Promise<boolean> {
  const result = await queryOne<{ count: number }>(
    "SELECT COUNT(*) as count FROM dislikes WHERE user_id = ? AND target_type = 'term' AND target_id = ?",
    [userId, termId]
  )
  return (result?.count || 0) > 0
}
